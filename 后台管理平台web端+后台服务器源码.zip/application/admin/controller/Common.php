<?php
namespace app\admin\controller;

class Common extends \think\Controller
{
	/**
	 * 函数名	:__construct
	 * 作用		:cotroller构造函数
	 * @return
	 */
   public function __construct() {
		parent::__construct();

		//public 目录
		$this->assign('spath','/static/admin');
		//加速地址
		$this->assign('spath_u',filebase().'/static/admin');
		$this->assign('sroot','/static');
		$this->assign('sroot_u',filebase().'/static');


		//URL前缀
		\think\Url::root('/admin.php');
		
		//系统信息
		$sysInfo = db('sys')->where( array('id'=>config('SYS_ID')) )->cache(true)->find();
		$this->sysInfo = $sysInfo;
		$this->assign('sysInfo',$sysInfo);
		$this->assign('modelTitle',$sysInfo['title']);

		$this->controllerName = strtolower(request()->controller());
		$this->actionName = strtolower(request()->action());
		
		//登陆验证
		$this->cl();
		
		//权限验证
		/*
		***********
		*/
		

		$getWhere = gwhere();
		$this->getWhere = $getWhere;
		$this->assign('getWhere',$getWhere);

		//菜单
		if(!request()->isAjax()){
			$menuLists = $this->getMenu();
			/*
			if($this->controllerName=='index'){
				$menuLists[0]['open'] = 1;
			}
			*/
			$this->assign('menuLists',$menuLists);

			$type_id = $this->adminInfo['admin_type_id'];
			

		}
		
		$this->addLog();
		

   }

   	//记录系统日志
	public function addLog(){
		$session = session(config('ADMIN_KEY'));
		if(($this->controllerName=='log' && $this->actionName=='index') || ($this->controllerName=='publics' && $this->actionName=='cqlv') ) {
			return true;
		}
		$data = array();
		$data['admin_id']	= $session['id'];
		$data['ma']			= $this->controllerName .'/'.$this->actionName;
		$data['http_url']	= 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
		$data['http_url_from']	= $_SERVER['HTTP_REFERER'];
		$data['get_json']	= json_encode(gwhere());
		$data['post_json']	= json_encode(input('post.'));
		$data['session_json']	= json_encode($session);
		$data['ip']	= get_ip();
		$data['update_time']	= time();
		$data['create_time']	= time();
		db('Log')->insert($data);
	}
   
   //登陆验证
   public function cl(){
		$controllerName = $this->controllerName;
		$noCheck = array('publics');

		if(!in_array($controllerName,$noCheck)){
			if(!session('?'.config('ADMIN_KEY'))){			
				return $this->redirect('Publics/index',array(), 0, '请登陆后访问！' );
			}
		}
		$this->adminInfo = admininfo();
		$this->assign('adminInfo',$this->adminInfo);
		
		

		
   }
   //导出   
   public function dc($filename='dc'){
	    $dc = (int)gwhere('dc');
		if($dc){
			$filename = $filename.'.xls';
			header('Content-type:application/vnd.ms-excel'); 
			header('Content-Disposition:attachment;filename='.$filename); 
			header('Pragma:no-cache'); 
			header('Expires:0');
		}
		$dcurl = url('',array_merge(gwhere(),array('dc'=>1)));
		$this->assign('dcurl',$dcurl);
		$this->assign('dc',$dc);
   }
   
	
   /**
     * 得到系统菜单
     * @return array
     */
	public function getMenu(){
		$moduleName = ucwords($this->controllerName);
		$actionName = $this->actionName;
		$maNow = $moduleName.'/'.$actionName;
		$adminInfo = session(config('ADMIN_KEY'));

		$adminTypeId = $adminInfo['admin_type_id'];
		
		$cache_key = 'admin_menu_'.$adminTypeId.'_'.md5($maNow);
		$menu = cache($cache_key);
		if($menu){
			return $menu;
		}

		//权限id列表
		$accessArray = array();
		if($adminTypeId!=config('ADMIN_TYPE_ID')){
			$adminAccess = db('Adminaccess')->where(array('type_id'=>$adminTypeId))->cache(true)->select();		
			foreach($adminAccess as $key=>$val){
				$accessArray[] = $val['access_id'];
			}
		}else{
			//超级管理员拥有所有权限
			$adminAccess = db('access')->where(array('admin_status'=>1))->cache(true)->select();	
			foreach($adminAccess as $key=>$val){
				$accessArray[] = $val['id'];
			}
		}
		
		
		
		$accessArray[] = 0;	
		$nowPid = db('access')->where(array('ma'=>$maNow))->cache(true)->value('pid');

		$menu = db('access')->where(array('pid'=>0,'status'=>1,'type_id'=>1,'id'=>array('in',$accessArray)))->order('o desc')->cache(true)->select();
		foreach($menu as $key=>$val){
			$pid					= $val['id'];
			$param					= $val['param'] ? json_decode($val['param'],true) : array();//链接参数
			$ma						= $val['ma'];	//链接操作方法
			$url					= url($ma,$param);	//生成链接

			//是否当前	
			if($nowPid==$pid){
				$menu[$key]['open'] = 1;
			}elseif($maNow==$val['ma']){
				$menu[$key]['open'] = 1;				
			}else{
				$menu[$key]['open'] = 0;
			}

			//二级菜单
			$menuC					= db('access')->where(array('pid'=>$pid,'status'=>1,'type_id'=>1,'id'=>array('in',$accessArray)))->order('o desc')->cache(true)->select();
			foreach($menuC as $keyC=>$valC){
				
				$paramC					= $valC['param'] ? json_decode($valC['param'],true) : array();//链接参数
				$ma						= $valC['ma'];	//链接操作方法
				$urlC					= url($ma,$paramC);	//生成链接
				$menuC[$keyC]['url']	= $urlC;
				if($ma==$maNow){
					$menuC[$keyC]['open']	= 1;
				}else{
					$menuC[$keyC]['open']	= 0;
				}
			}

			$menu[$key]['url']	= $url;
			$menu[$key]['child']	= $menuC;
		}

		cache($cache_key,$menu);
		return $menu;
		
	}


	/**
     * 得到数据分页
     * @param  string $modelName 模型名称
     * @param  array  $where     分页条件
     * @return array
     */
    protected function getPagination($modelName, $where, $fields, $order, $pageSize = 10) {
		

		if(isset($this->getWhere['pagesize'])){
			$pageSize = $this->getWhere['pagesize'];
		}
		$ModelD = db($modelName);
		$totalRows = $ModelD->where($where)->field($fields)->count();
		$p = isset($this->getWhere['p']) ? $this->getWhere['p'] : 1;
        $Page = new \think\Page($totalRows,$pageSize,'p');
		$data = $ModelD->where($where)->field($fields)->page($p,$pageSize)->order($order)->select();
		
		$result['show'] = $Page->show();
        $result['data'] = $data;
        $result['total_rows'] = $totalRows;
        return $result;
    }

   /**
     * { status : true, info: $info}
     * @param  string $info
     * @param  string $url
     * @return
	 success($msg = '', $url = null, $data = '', $wait = 3, array $header = [])
     */
    protected function successReturn( $info='', $url=null ,$data='') {
   
	   return $this->resultReturn(true, $info, $url,$data);
    }

    /**
     * { status : false, info: $info}
     * @param  string $info
     * @param  string $url
     * @return
     */
    protected function errorReturn( $info='', $url=null ,$data='') {
    
		return $this->resultReturn(false, $info, $url,$data);
    }
	

	/**
     * 返回带有status、info键值的json数据
     * @param  boolean $status
     * @param  string $info
     * @param  string $url
     * @return
     */

    protected function resultReturn($status, $info='', $url=null ,$data='') {
		if(request()->isAjax()){
			$json['status'] = $status;
			$json['info'] = $info;
			$json['url'] = $url;
			$json['data'] = $data;
			return $json;
		}


		if(!$status){
			return $this->error($info, $url, $data);
		}
		return $this->success($info, $url, $data);
		
    }

	/**
     * 下载文件
     * @param  文件路径 $filePath
     * @param  文件名称 $fileName
     * @return
     */
    protected function download($file_url,$new_name=''){  
		if(!isset($file_url)||trim($file_url)==''){  
			return '500';  
		}  
		if(!file_exists($file_url)){ //检查文件是否存在  
			return '404';  
		}  
		$file_name=basename($file_url);  
		$file_type=explode('.',$file_url);  
		$file_type=$file_type[count($file_type)-1];  
		$file_name=trim($new_name=='')?$file_name:urlencode($new_name);  
		$file_type=fopen($file_url,'r'); //打开文件  
		//输入文件标签  
		header("Content-type: application/octet-stream");  
		header("Accept-Ranges: bytes");  
		header("Accept-Length: ".filesize($file_url));  
		header("Content-Disposition: attachment; filename=".$file_name);  
		//输出文件内容  
		echo fread($file_type,filesize($file_url));  
		fclose($file_type);  
	} 

}
