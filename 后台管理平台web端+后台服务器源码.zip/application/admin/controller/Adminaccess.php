<?php
namespace app\admin\controller;

class Adminaccess extends Common{
	public function abcd(){
		$Access = db('Access');
		$pid = 3;
		$name = '鱼类表单';
		$startId = 3070;
		$moduleName = 'Wtbd';
		
		$data = array( 'id'=>$startId,
						'type_id'=>1,
						'pid'=>$pid,
						'i_class'=>'',
						'title'=>$name,
						'ma'=>$moduleName.'/index',
						'admin_status'=>1
				);
		$Access->insert($data);
		$startId++;

		$data = array( 'id'=>$startId,
						'type_id'=>2,
						'pid'=>$pid,
						'i_class'=>'',
						'title'=>'添加'.$name,
						'ma'=>$moduleName.'/add',
						'admin_status'=>1
				);
		$Access->insert($data);
		$startId++;

		$data = array( 'id'=>$startId,
						'type_id'=>3,
						'pid'=>$pid,
						'i_class'=>'',
						'title'=>'创建'.$name,
						'ma'=>$moduleName.'/create',
						'admin_status'=>1
				);
		$Access->insert($data);
		$startId++;

		$data = array( 'id'=>$startId,
						'type_id'=>2,
						'pid'=>$pid,
						'i_class'=>'',
						'title'=>'编辑'.$name,
						'ma'=>$moduleName.'/edit',
						'admin_status'=>1
				);
		$Access->insert($data);
		$startId++;

		$data = array( 'id'=>$startId,
						'type_id'=>3,
						'pid'=>$pid,
						'i_class'=>'',
						'title'=>'提交'.$name,
						'ma'=>$moduleName.'/update',
						'admin_status'=>1
				);
		$Access->insert($data);
		$startId++;

		$data = array( 'id'=>$startId,
						'type_id'=>2,
						'pid'=>$pid,
						'i_class'=>'',
						'title'=>'删除'.$name,
						'ma'=>$moduleName.'/delete',
						'admin_status'=>1
				);
		$Access->insert($data);
		$startId++;

		$data = array( 'id'=>$startId,
						'type_id'=>2,
						'pid'=>$pid,
						'i_class'=>'',
						'title'=>$name.'详情',
						'ma'=>$moduleName.'/show',
						'admin_status'=>1
				);
		$Access->insert($data);
		$startId++;
		/*
		$data = array( 'id'=>$startId,
						'type_id'=>2,
						'pid'=>$pid,
						'i_class'=>'',
						'title'=>'置顶'.$name,
						'ma'=>$moduleName.'/top',
						'admin_status'=>1
				);
		$Access->add($data);
		$startId++;
		*/
		$this->success('添加完成',url('Index/index'));

	}
	//首页
    public function index(){

		$lists = db('admintype')->where(array('id'=>array('neq',config('ADMIN_TYPE_ID')),'status'=>1))->select();
		$this->assign('lists',$lists);
	
        return $this->fetch();
    }
	//修改权限
	public function edit(){
		$type_id = (int)gwhere('id');
		$title = db('admintype')->where( array('id'=>$type_id) )->value('title');
		$this->assign('title',$title);

		$Access = db('Access');
		$Admin_access = db('Adminaccess');
		
		$adminAccessres = $Admin_access->where(array('type_id'=>$type_id))->select();
		$adminAccess = array();
		foreach($adminAccessres as $key=>$val){
			$adminAccess[] = $val['access_id'];
		}

		$accessLists = $Access->where(array('pid'=>0,'status'=>1))->order('o desc,id asc')->select();
		foreach($accessLists as $key=>$val){
			$pid = $val['id'];
			$childLists = $Access->where(array('pid'=>$pid,'status'=>1))->order('o desc,id asc')->select();
			$accessLists[$key]['childLists'] = $childLists;
		}
		

		
		$this->assign('type_id',$type_id);
		$this->assign('adminAccess',$adminAccess);
		$this->assign('accessLists',$accessLists);
		return $this->fetch();
	}
	public function update(){

		$type_id = (int)input('post.type_id');
		
		
		$Access = db('Access');
		$Admin_access = db('Adminaccess');
		$access = input('post.access_id/a');
		
		$Admin_access->where(array('type_id'=>$type_id))->delete();
		$dataArr = array();
		foreach($access as $key=>$val){
			$data = array('type_id'=>$type_id,'access_id'=>$val);
			$dataArr[] = $data;
			//$Admin_access->add($data);
		}
		
		$Admin_access->insertAll($dataArr);
		return $this->successReturn( '操作成功',url('index') );

	}

}
