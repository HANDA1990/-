<?php
namespace app\admin\controller;
class Error  extends Common{
    public function _empty(){
		
		$actionName = $this->actionName;
		$this->$actionName();
		
    }
    /*列表页*/
	public function index(){
		$controllerName = ucwords($this->controllerName);
		
		$Model = model($controllerName);
		//判断是否是配置的model
		if(!$Model->modelTitle){
			$this->error(L('404'));
		}
		//首页重定向
		$indexUrl = $Model->indexUrl;
		//首页过滤
		if($indexUrl){
			return redirect($indexUrl, 0, L('jump_msg'));
		}

		//模型名称
		$modelTitle = $Model->modelTitle;

		//字段详情
		$myFields = $Model->myFields();
		
		
		//列表显示字段
		$listField = $Model->listField;
		
		

		//分页大小
		$pageSize = $Model->pageSize ? $Model->pageSize : 10;
		
		
		//$rows = db($controllerName)->page('1,10')->select();
		$searchHtml = getSearchFormElement($Model);
		$where = getListWhere($Model);
		$order = $Model->orders;

		$tableName = $Model->tableMy ? $Model->tableMy : $controllerName;
		$result = $this->getPagination($tableName, $where, '', $order,$pageSize);
		$rows = $result['data'];
		$page = $result['show'];
		$totalRows = $result['total_rows'];
		$this->assign('rows',$rows);
		$this->assign('page',$page);
		$this->assign('totalRows',$totalRows);

		$this->assign('modelTitle',$modelTitle);
		$this->assign('searchHtml',$searchHtml);
		$this->assign('myFields',$myFields);
		$this->assign('listField',$listField);
		$this->assign('controllerName',$controllerName);

		$tpl = $Model->indexTpl;
		$tpl = $tpl ? $tpl : 'empty:index';
		return $this->fetch($tpl);
	}

	/*列表页*/
	public function dcsj(){
		$controllerName = ucwords($this->controllerName);
		
		$Model = model($controllerName);
		//判断是否是配置的model
		if(!$Model->modelTitle){
			$this->error(L('404'));
		}
		//首页重定向
		$indexUrl = $Model->indexUrl;
		//首页过滤
		if($indexUrl){
			return redirect($indexUrl, 0, L('jump_msg'));
		}

		//模型名称
		$modelTitle = $Model->modelTitle;

		//字段详情
		$myFields = $Model->myFields();
		
		
		//列表显示字段
		$listField = $Model->dcField;
		
		

		//分页大小
		$pageSize = 10000;
		
		
		//$rows = db($controllerName)->page('1,10')->select();
		$searchHtml = getSearchFormElement($Model);
		$where = getListWhere($Model);
		$order = $Model->orders;
		
		$tableName = $Model->tableMy ? $Model->tableMy : $controllerName;
		$result = $this->getPagination($tableName, $where, '', $order,$pageSize);
		$rows = $result['data'];
		$page = $result['show'];
		$totalRows = $result['total_rows'];
		$this->assign('rows',$rows);
		$this->assign('page',$page);
		$this->assign('totalRows',$totalRows);

		$this->assign('modelTitle',$modelTitle);
		$this->assign('searchHtml',$searchHtml);
		$this->assign('myFields',$myFields);
		$this->assign('listField',$listField);
		$this->assign('controllerName',$controllerName);
		

			$filename = $modelTitle.'.xls';
			header('Content-type:application/vnd.ms-excel'); 
			header('Content-Disposition:attachment;filename='.$filename); 
			header('Pragma:no-cache'); 
			header('Expires:0');

		$tpl = $Model->dcTpl;
		$tpl = $tpl ? $tpl : 'empty:dcsj';
		return $this->fetch($tpl);
	}
	/*添加页面*/
	public function add(){
		$controllerName = ucwords($this->controllerName);
		
		$Model = model($controllerName);
		//判断是否是配置的model
		if(!$Model->modelTitle){
			$this->error(L('404'));
		}

		//模型名称
		$modelTitle = $Model->modelTitle;

		//字段详情
		$myFields = $Model->myFields();
		
		$tableName = $Model->tableMy ? $Model->tableMy : $controllerName;
		$this->assign('tableName',$tableName);
		$this->assign('modelTitle',$modelTitle);
		$this->assign('myFields',$myFields);
		$this->assign('controllerName',$controllerName);	
		

		$tpl = $Model->addTpl;
		$tpl = $tpl ? $tpl : 'empty:add';
		return $this->fetch($tpl);
	}
	
	
	/**
     * 编辑信息页
     * @return
     */
    public function edit(){
		$id = (int)gwhere('id');

		$controllerName = ucwords($this->controllerName);
		
		$Model = model($controllerName);
		//模型名称
		$modelTitle = $Model->modelTitle;
		
		//字段详情
		$myFields = $Model->myFields();


		//编辑过滤条件
		$editWhere = $Model->editWhere ? $Model->editWhere : array();
		$where = array('id'=>$id);
		$where = array_merge($where,$editWhere);
		
		$tableName = $Model->tableMy ? $Model->tableMy : $controllerName;
		$info = db($tableName)->where($where)->find();
		if(!$info){
			return $this->error( '未找到信息' );
		}
		
		//文件列表
		$imgList = $Model->imgList;
		$this->assign('imgList',$imgList);
		$this->assign('tableName',$tableName);

		$this->assign('info',$info);
		$this->assign('modelTitle',$modelTitle);
		$this->assign('myFields',$myFields);
		$this->assign('controllerName',$controllerName);	

		$tpl = $Model->editTpl;
		$tpl = $tpl ? $tpl : 'empty:edit';
		return $this->fetch($tpl);
	}
	/**
     * 查看信息页
     * @return
     */
    public function show(){
		$id = (int)gwhere('id');

		$controllerName = ucwords($this->controllerName);
		
		$Model = model($controllerName);
		//模型名称
		$modelTitle = $Model->modelTitle;
		
		//字段详情
		$myFields = $Model->myFields();


		//编辑过滤条件
		$editWhere = $Model->showWhere ? $Model->showWhere : array();
		$where = array('id'=>$id);
		$where = array_merge($where,$editWhere);
		
		$tableName = $Model->tableMy ? $Model->tableMy : $controllerName;
		$info = db($tableName)->where($where)->find();
		if(!$info){
			return $this->error( '未找到信息' );
		}
		
		//文件列表
		$imgList = $Model->imgList;
		$this->assign('imgList',$imgList);
		$this->assign('tableName',$tableName);

		$this->assign('info',$info);
		$this->assign('modelTitle',$modelTitle);
		$this->assign('myFields',$myFields);
		$this->assign('controllerName',$controllerName);	

		$tpl = $Model->showTpl;
		$tpl = $tpl ? $tpl : 'empty:show';
		return $this->fetch($tpl);
	}
	/**
     * 创建信息
     * @return
     */
    public function create(){
		$data = input('post.');

		$HTTP_REFERER = hscd(input('post.HTTP_REFERER'));
		$controllerName = ucwords($this->controllerName);
		
		$Model = model($controllerName);
		

		
		//字段详情
		$myFields = $Model->myFields();
		$data = $Model->makeData($data,$myFields);//过滤数据（checkbox值组合，文件处理等）
		
		//验证数据

		$data = $Model->createData($data);
		if(!is_array($data)){
			return $this->errorReturn($data);
		}

		$result = $Model->addData($data);
		if(!$result){
			return $this->errorReturn( '添加失败' );
		}
		

		$Model->completeData($data,$myFields);
		
		$reload_url = $Model->reloadUrl;		
		$reload_url = $reload_url ? $reload_url : ( $HTTP_REFERER ? $HTTP_REFERER :  url($controllerName.'/index') );
		return $this->successReturn( '操作成功！' ,$reload_url);
	}

	/**
     * 更新信息
     * @return
     */
    public function update(){
		$data = input('post.');
		$id = (int)$data['id'];
		$HTTP_REFERER = hscd(input('post.HTTP_REFERER'));
		$controllerName = ucwords($this->controllerName);
		
		$Model = model($controllerName);
		
		
		//字段详情
		$myFields = $Model->myFields();
		$data = $Model->makeData($data,$myFields);//过滤数据（checkbox值组合，文件处理等）

		$data = $Model->updateData($data);
		if(!is_array($data)){
			return $this->errorReturn($data);
		}
		
		//编辑过滤条件
		$editWhere = $Model->editWhere ? $Model->editWhere : array();
		$where = array('id'=>$id);
		$where = array_merge($where,$editWhere);
		
		$result = $Model->saveData($data,$where);
		if($result===false){
			return $this->errorReturn( '操作失败!' );
		}
		
		$Model->completeData($data,$myFields);
		
		//成功跳转路径
		$reload_url = $Model->reloadUrl;		
		$reload_url = $reload_url ? $reload_url : ( $HTTP_REFERER ? $HTTP_REFERER :  url($controllerName.'/index') );
		return $this->successReturn( '操作成功' ,$reload_url);
	}
		//删除
	public function delete(){
		$id = (int)gwhere('id');
		$controllerName = ucwords($this->controllerName);
		
		$Model = model($controllerName);

		

		//字段详情
		$myFields = $Model->myFields();

		$tableName = $Model->tableMy ? $Model->tableMy : $controllerName;
		$info = db($tableName)->where(array('id'=>$id))->find();
		if(!$info){
			return $this->errorReturn( '未找到信息' );
		}

		//编辑过滤条件
		$deleteWhere = $Model->deleteWhere;
		$where = array('id'=>$id);
		$where = array_merge($where,$deleteWhere);

		$result = db($tableName)->where($where)->delete();
		if(!$result){
			return $this->errorReturn( '删除失败' );
		}
		
		$Model->clearData($info,$myFields,strtolower($tableName));
		
		return $this->successReturn('','reload');

	}
	public function deleteall(){
		$ids = input('post.id/a');
		$controllerName = ucwords($this->controllerName);

		$Model = model($controllerName);

		//字段详情
		$myFields = $Model->myFields();
		
		//编辑过滤条件
		$deleteWhere = $Model->deleteWhere;
		$where = array('id'=>array('in',$ids));
		$where = array_merge($where,$deleteWhere);
		
		$tableName = $Model->tableMy ? $Model->tableMy : $controllerName;
		$infoLists = db($tableName)->where( $where )->select();
		$result = db($tableName)->where( $where )->delete();
		if(!$result){
			return $this->errorReturn( '删除失败' );
		}
		
		
		foreach($infoLists as $key=>$val){
			$info = $val;
			$Model->clearData($info,$myFields,strtolower($tableName));
		}
		
		return $this->successReturn('','reload');
	}

   
}