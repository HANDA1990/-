<?php
namespace app\admin\controller;

class Orders extends Common{
	
	public function index(){
		
		$where = array();
		$lists = db('orders')->where( $where )->order('id desc')->limit(0,10)->select();
		$this->assign('lists',$lists);
		return $this->fetch();
    }
	
	
    
}
