<?php
namespace app\admin\controller;

class Psw extends Common{
	
	
	//修改密码
	public function psw(){
		return $this->fetch();
	}
	public function pswupdate(){
		$oldPassword = encrypt_my(input('post.oldpassword'));
		$password = encrypt_my(input('post.password'));
		$rePassword = encrypt_my(input('post.repassword'));
		$Model = db('admin');
		$oldPasswordDb = $Model->where(array('id'=>$this->adminInfo['id']))->value('password');
		if($oldPassword != $oldPasswordDb){
			return $this->errorReturn('原始密码错误！');
		}

		$result = $Model->where(array('id'=>$this->adminInfo['id']))->setField('password',$password);
		if($result===false){
			return $this->errorReturn('修改失败！');
		}

		return $this->successReturn('修改成功',url('index/index'));
	}

	//重置密码
	public function pswreset(){
		$id = (int)gwhere('id');
		$Model = db('Admin');
		$info = $Model->where( array('id'=>$id) )->find();
		if(!$info){
			return $this->errorReturn('未找到信息');
		}
		
		$data = array('password'=>def_password(),'update_time'=>time());
		$result = $Model->where( array('id'=>$info['id']) )->update($data);
		if(!$result){
			return $this->errorReturn('修改失败');
		}
		return $this->successReturn('重置成功');
	}
	//监管平台重置密码
	public function jgptpswreset(){
		$id = (int)gwhere('id');
		$Model = db('Jgpt');
		$info = $Model->where( array('id'=>$id) )->find();
		if(!$info){
			return $this->errorReturn('未找到信息');
		}
		
		$data = array('password'=>def_password(),'update_time'=>time());
		$result = $Model->where( array('id'=>$info['id']) )->update($data);
		if(!$result){
			return $this->errorReturn('修改失败');
		}
		return $this->successReturn('重置成功');
	}

	
}
