<?php
namespace app\admin\controller;
use think\Db;
class Publics extends Common{
	
	//在线设备列表
	public function oc(){
		$lists = db('cardid')->where(['card_type'=>array('in','TR,WL'),'update_time'=>array('gt',time()-180)])->select();
		//$lists = db('cardid')->where(['card_type'=>array('in','TR')])->select();
		$this->assign('lists',$lists);
		return $this->fetch();
	}
	
	public function infopage(){
		$info = db('sys')->where( array('id'=>config('SYS_ID')) )->find();
		return view('infopage',['info'=>$info]);
	}

	//登陆页面
    public function index(){
        return $this->fetch();
    }
	
	//登录处理
	public function logindo(){
		

		$verf = input('post.verf');
		if(!captcha_check($verf)){
			return $this->errorReturn('验证码错误！');
		};
		
		
		$account = input('post.account');
		$password = encrypt_my(input('post.password'));

		$DBModel = DB::name('Admin');
		$adminInfo = $DBModel->where( array('account'=>$account,'password'=>$password,'status'=>1) )->find();
		if(!$adminInfo){
			return $this->errorReturn('账号或密码错误');
		}
		$DBModel->where( array('id'=>$adminInfo['id']) )->setField('login_time',time());
		session(config('ADMIN_KEY'),$adminInfo);
		return $this->successReturn('',url('Index/index'));
	}
	
	//退出登录
	public function logout(){
		
		$url = url('publics/index');		
		session(config('ADMIN_KEY'),null);
		return $this->successReturn('',$url);
		
	}
	

}
