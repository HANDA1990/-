<?php
namespace app\admin\controller;
class Cardid extends Common{
	public function _empty($name)
    {	
		$Error = controller('Error');
		return $Error->$name();
       
    }
	public function index()
    {	
		//更新设备在线
		db('cardid')->where(['id'=>array('gt',0)])->setField('is_online',0);
		db('cardid')->where(['update_time'=>array('gt',time()-120)])->setField('is_online',1);

		$Error = controller('Error');
		return $Error->index();
       
    }
}
