<?php
namespace app\admin\controller;

class Files extends Common{
	
	/**
     * 图片上传
     * 
     */
    public function uploadify(){
		
		
		$name = 'uploadedfile';
		$result = uploadByName($name);
		if(!$result){
			return $this->errorReturn('文件格式或大小错误！');
		}

		//写入临时文件表
		$data = array('create_time'=>time(),'file_url'=>$result);
		db('Tempfile')->insert($data);
		return $this->successReturn($result);
	
    }
	/* 上传图片 */
	public function eupload(){
		$return  = array('error' => 0, 'info' => '上传成功', 'data' => '');
		$info = uploadByName('imgFile');
		if($info){		
			$return['url'] = '/'.$info;
			unset($return['info'], $return['data']);
		}else {
			$return['error'] = 1;
			$return['message']   = '文件格式或大小错误！';
		}
	
		/* 返回JSON数据 */
		return json_encode($return);
	}

	/*
	*文件列表上传
	*/
	public function filelists(){
		$tableName = input('post.table_name');
		$id = (int)input('post.id');
		$name = 'uploadedfile_list';
		$result = uploadByName($name);
		if(!$result){
			return $this->errorReturn('文件格式或大小错误！');
		}

		$data = array();
		$data['table_name'] = $tableName;
		$data['pid'] = $id;
		$data['file_url'] = $result;
		$data['file_size'] = filesize($result);
		$data['create_time'] = time();
		$data['update_time'] = time();

		db('filelists')->insert($data);
		return $this->successReturn($result);
	}

	/*
	*文件列表
	*/
	public function tablefilelist(){
		$tableName = gwhere('table_name');
		$id = (int)gwhere('id');
		$delete = (int)gwhere('delete');
		
		$where = array('pid'=>$id,'table_name'=>$tableName);
		$lists = db('filelists')->where($where)->select();

		$this->assign('delete',$delete);
		$this->assign('lists',$lists);
		return view();
	}
	/*
	*删除文件列表
	*/
	public function deleteone(){
		$id = (int)gwhere('id');
		$Model = db('filelists');

		$info = $Model->where(array('id'=>$id))->find();
		if(!$info){
			return $this->errorReturn('要删除的文件不存在！');
		}

		$file_url = $info['file_url'];
		$result = $Model->where(array('id'=>$id))->delete();
		if($result===false){
			return $this->errorReturn('要删除的文件不存在！');
		}
		
		return $this->successReturn('删除成功');

	}
}
