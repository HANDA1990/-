<?php
namespace app\admin\controller;
use think\Db;
class Index extends Common{
	
	public function index(){	
		
		//在线设备
		$onlineCount = db('cardid')->where( array('update_time'=>array('gt',time()-120)) )->count();
		$cardCount = db('cardid')->count();
		$bindCount = db('acccard')->count('distinct card_id'); 
		//用户
		$acconlineCount = db('account')->where( array('login_time'=>array('gt',time()-24*60*60)) )->count();
		$accCount = db('account')->count();
		$accbindCount = db('acccard')->count('distinct account_id');

		$this->assign( ['onlineCount'=>$onlineCount,'cardCount'=>$cardCount,'bindCount'=>$bindCount,'acconlineCount'=>$acconlineCount,'accCount'=>$accCount,'accbindCount'=>$accbindCount] );

		return $this->fetch();
	}
	
	//清除缓存
	public function clear(){
		\think\Cache::clear();
		
		/*
		$sql = 'truncate table think_accountlog';
		Db::execute($sql);
		$sql = 'truncate table think_log';
		Db::execute($sql);
		$sql = 'truncate table think_msglog';
		Db::execute($sql);
		*/

		//更新设备在线
		db('cardid')->where(['id'=>array('gt',0)])->setField('is_online',0);
		db('cardid')->where(['update_time'=>array('gt',time()-120)])->setField('is_online',1);

		//删除datalog
		$time_limit = time()-7*24*60*60;
		db('datalog')->where( array('create_time'=>array('lt',$time_limit)) )->delete();

		if(request()->isAjax()){
			return $this->successReturn('清除缓存成功！','reload');
		}else{
			return $this->successReturn('清除缓存成功！');
		}

	}
}
