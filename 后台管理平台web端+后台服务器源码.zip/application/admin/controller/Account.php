<?php
namespace app\admin\controller;
class Account extends Common{
	public function _empty($name)
    {	
		$Error = controller('Error');
		return $Error->$name();
       
    }
}
