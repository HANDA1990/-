<?php
namespace app\admin\controller;

class Czjl extends Common{
	
	
	//修改密码
	public function index(){
		$pageSize = 10;
		$ModelD = db('articlesjl');
		$where = ['nickname'=>array('neq',''),'type_str'=>'djkf'];
		$title = gwhere('title');
		if($title){
			$where['nickname'] = array('like',"%{$title}%");
		}
		$totalRows = $ModelD->where($where)->group('openid,type_str')->field('openid,nickname,headimgurl,type_str,count(*) nums')->count();
		$p = isset($this->getWhere['p']) ? $this->getWhere['p'] : 1;
        $Page = new \think\Page($totalRows,$pageSize,'p');
		$data = $ModelD->where($where)->group('openid,type_str')->field('openid,nickname,headimgurl,type_str,count(*) nums')->page($p,$pageSize)->order($order)->select();
		
		$result['show'] = $Page->show();
        $result['data'] = $data;
		$this->assign('totalRows',$totalRows);
		$this->assign('lists',$data);
		$this->assign('page',$Page->show());
		return $this->fetch();
	}
	
}
