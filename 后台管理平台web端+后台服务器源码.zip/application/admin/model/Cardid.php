<?php
namespace app\admin\model;
use think\Model;
/*系统账号*/
class Cardid extends Common{
	
	
	public $pageSize = 10;
	public $orders = 'id desc';
	public $modelTitle	= '设备信息';
	public $searchField = array( ['name'=>'card_type'],['name'=>'is_online'] );
	
	public $listField = array(
        array('name'=>'id','title'=>'ID'),
		        
        array(
            'name' => 'card_type',
            'title' => '类型'
        ) ,        
        array(
            'name' => 'card_id',
            'title' => '设备id'
        ) ,        
        array(
            'name' => 'value_json_kg',
            'title' => '报警开关'
        ) ,     
        array(
            'name' => 'is_online',
            'title' => '在线'
        ) ,	    
        array(
            'name' => 'update_time',
            'title' => '在线时间'
        ) ,		     
        array(
            'name' => 'ip_1',
            'title' => 'IP'
        ) ,	 	     
        array(
            'name' => 'status',
            'title' => '状态'
        ) ,	      
        
    );
	/**
	 * 函数名	:_initialize
	 * 作用		:thinkphp Action的构造函数,用来初始化
	 * @return
	 */
	public function __construct(){
		parent::__construct();
		
	}

	

	//列表编辑
   public function myFields(){
	   
	  $my_fields = array(
		   //edit : 0 不允许编辑 ，1 允许编辑，2 只许查看不许编辑	
			
			'card_type' => array(
                'type' => 'radio',
                'name' => 'card_type',
                'title' => '类型',
                'validate' => '*',
                'dataKey' => 'card_type',
				'add'=>0,
				'edit'=>2
            ) ,
			
			'card_id' => array(
                'type' => 'text',
                'name' => 'card_id',
                'title' => '设备id',
                'validate' => '*',
				'add'=>0,
				'edit'=>2
            ) ,
			'value_json_kg' => array(
                'type' => 'text',
                'name' => 'value_json_kg',
                'title' => '报警开关',
                'validate' => '*',
				'add'=>0,
				'edit'=>2
            ) ,
			'ip_1' => array(
                'type' => 'text',
                'name' => 'ip_1',
                'title' => 'IP',
                'validate' => '*',
				'add'=>0,
				'edit'=>2
            ) ,
			
			'update_time' => array(
                'type' => 'timestamp',
                'name' => 'update_time',
                'title' => '在线时间',
                'validate' => '*',
				'add'=>0,
				'edit'=>2
            ) ,
			
			'is_online' => array(
                'type' => 'radio',
                'name' => 'is_online',
                'title' => '在线',
                'validate' => '*',
                'dataKey' => 'common_bool',
				'value'=>1,
				'add'=>0,
				'edit'=>2
            ) ,
			'status' => array(
                'type' => 'radio',
                'name' => 'status',
                'title' => '状态',
                'validate' => '*',
                'dataKey' => 'common_status',
				'value'=>1,
				'add'=>0,
				'edit'=>2
            ) ,
            
			
	   );
	  
	   return $my_fields;
   }


}