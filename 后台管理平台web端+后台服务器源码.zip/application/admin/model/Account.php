<?php
namespace app\admin\model;
use think\Model;
/*系统账号*/
class Account extends Common{
	public $pageSize = 10;
	public $orders = 'id desc';
	public $modelTitle	= '会员';
	public $searchField = array( array('name'=>'account'),array('name'=>'title'),array('name'=>'create_time') );
	
	public $listField	= array(
							//array('name'=>'id','title'=>'ID'),
							array('name'=>'account','title'=>'账号'),
							array('name'=>'title','title'=>'昵称'),
							array('name'=>'file_url','title'=>'头像'),
							array('name'=>'status','title'=>'状态'),
							array('name'=>'create_time','title'=>'注册时间')
						);
	public $dcField	= array(
							//array('name'=>'id','title'=>'ID'),
							array('name'=>'account','title'=>'账号'),
							array('name'=>'title','title'=>'昵称'),
							array('name'=>'file_url','title'=>'头像'),
							array('name'=>'sex','title'=>'性别'),
							array('name'=>'province','title'=>'省'),
							array('name'=>'city','title'=>'市'),
							array('name'=>'area','title'=>'区'),
							array('name'=>'status','title'=>'状态'),
							array('name'=>'create_time','title'=>'注册时间')
						);
	/**
	 * 函数名	:_initialize
	 * 作用		:thinkphp Action的构造函数,用来初始化
	 * @return
	 */
	public function __construct(){
		parent::__construct();
		
	}

	

	//列表编辑
   public function myFields(){
	   
	   $my_fields = array(
		    
			
			
			'account' => array(
                'type' => 'text',
                'name' => 'account',
                'title' => '账号',
                'validate' => '*'
            ) ,
			'file_url' => array(
                'type' => 'img',
                'name' => 'file_url',
                'title' => '头像',
                'validate' => ''
            ) ,
			'title' => array(
                'type' => 'text',
                'name' => 'title',
                'title' => '昵称',
                'validate' => '*'
            ) ,
			'sex' => array(
                'type' => 'radio',
                'name' => 'sex',
                'title' => '性别',
                'validate' => '',
                'dataKey' => 'common_sex_text',
            ) ,
			'province' => array(
                'type' => 'text',
                'name' => 'province',
                'title' => '省',
                'validate' => ''
            ) ,
			'city' => array(
                'type' => 'text',
                'name' => 'city',
                'title' => '市',
                'validate' => ''
            ) ,
			'area' => array(
                'type' => 'text',
                'name' => 'area',
                'title' => '区',
                'validate' => ''
            ) ,
			'email' => array(
                'type' => 'text',
                'name' => 'email',
                'title' => '邮件',
                'validate' => ''
            ) ,
			'create_time' => array(
                'type' => 'timestamp',
                'name' => 'create_time',
                'title' => '注册时间',
                'validate' => '',
				'edit'=>2
            ) ,	
			
			
			'status' => array(
                'type' => 'radio',
                'name' => 'status',
                'title' => '状态',
                'validate' => '',
                'dataKey' => 'common_status',
				'value'=>1
            ) ,
			
		    
	   );
	  
	   return $my_fields;
   }


}