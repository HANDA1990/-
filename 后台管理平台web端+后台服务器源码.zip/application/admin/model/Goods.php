<?php
namespace app\admin\model;
use think\Model;
/*系统账号*/
class Goods extends Common{
	public $pageSize = 10;
	public $orders = 'o desc,id desc';
	public $modelTitle	= '产品';
	public $searchField = array( array('name'=>'title') );
	
	public $listField	= array(
							//array('name'=>'id','title'=>'ID'),
							array('name'=>'title','title'=>'名称'),
							array('name'=>'file_url','title'=>'图片'),
							array('name'=>'guige','title'=>'规格'),
							array('name'=>'yanse','title'=>'颜色'),
							array('name'=>'xinghao','title'=>'型号'),
							array('name'=>'price','title'=>'价格'),
							array('name'=>'status','title'=>'状态'),
						);
	
	/**
	 * 函数名	:_initialize
	 * 作用		:thinkphp Action的构造函数,用来初始化
	 * @return
	 */
	public function __construct(){
		parent::__construct();
		
	}

	

	//列表编辑
   public function myFields(){
	   
	   $my_fields = array(
		    
			'file_url' => array(
                'type' => 'img',
                'name' => 'file_url',
                'title' => '图片',
                'validate' => ''
            ) ,
			'title' => array(
                'type' => 'text',
                'name' => 'title',
                'title' => '名称',
                'validate' => '*'
            ) ,
			'guige' => array(
                'type' => 'text',
                'name' => 'guige',
                'title' => '规格',
                'validate' => ''
            ) ,
			'yanse' => array(
                'type' => 'text',
                'name' => 'yanse',
                'title' => '颜色',
                'validate' => ''
            ) ,
			'xinghao' => array(
                'type' => 'text',
                'name' => 'xinghao',
                'title' => '型号',
                'validate' => ''
            ) ,
			'yuanjia' => array(
                'type' => 'text',
                'name' => 'yuanjia',
                'title' => '原价',
                'validate' => '',
                'value' => 0,
            ) ,
			'price' => array(
                'type' => 'text',
                'name' => 'price',
                'title' => '现价',
                'validate' => '',
                'value' => 0,
            ) ,
			'contents' => array(
                'type' => 'editor',
                'name' => 'contents',
                'title' => '详情',
                'validate' => ''
            ) ,
			'app_contents' => array(
                'type' => 'editor',
                'name' => 'app_contents',
                'title' => '手机详情',
                'validate' => ''
            ) ,
			
			
			'status' => array(
                'type' => 'radio',
                'name' => 'status',
                'title' => '状态',
                'validate' => '',
                'dataKey' => 'common_status',
				'value'=>1
            ) ,
			
		    
	   );
	  
	   return $my_fields;
   }


}