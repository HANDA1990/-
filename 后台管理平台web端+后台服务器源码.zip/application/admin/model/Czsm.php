<?php
namespace app\admin\model;
use think\Model;
/*系统账号*/
class Czsm extends Common{
	
	
	public $pageSize = 10;
	public $orders = 'o asc,id asc';
	public $modelTitle	= '操作说明';
	public $searchField = array();
	
	public $listField	= array(
							//array('name'=>'id','title'=>'ID'),
							array('name'=>'title','title'=>'标题'),
							array('name'=>'file_url','title'=>'图片'),
							array('name'=>'sub_title','title'=>'简介'),
							array('name'=>'o','title'=>'排序'),
							array('name'=>'status','title'=>'状态'),
							//array('name'=>'create_time','title'=>'发布时间')
						);
	/**
	 * 函数名	:_initialize
	 * 作用		:thinkphp Action的构造函数,用来初始化
	 * @return
	 */
	public function __construct(){
		parent::__construct();
		
	}

	

	//列表编辑
   public function myFields(){
	   
	   $my_fields = array(
		   
			'file_url' => array(
                'type' => 'img',
                'name' => 'file_url',
                'title' => '图片',
                'validate' => ''
            ) ,
			'title' => array(
                'type' => 'text',
                'name' => 'title',
                'title' => '标题',
                'validate' => '*'
            ) ,
			'sub_title' => array(
                'type' => 'text',
                'name' => 'sub_title',
                'title' => '简介',
                'validate' => ''
            ) ,
			'app_contents' => array(
                'type' => 'editor',
                'name' => 'app_contents',
                'title' => '手机详情',
                'validate' => ''
            ) ,
			
			'o' => array(
                'type' => 'text',
                'name' => 'o',
                'title' => '排序',
                'validate' => 'n',
				'value'=>0
            ) ,
			
			
			'status' => array(
                'type' => 'radio',
                'name' => 'status',
                'title' => '状态',
                'validate' => '',
                'dataKey' => 'common_status',
				'value'=>1
            ) ,
			
		    
	   );
	  
	   return $my_fields;
   }


}