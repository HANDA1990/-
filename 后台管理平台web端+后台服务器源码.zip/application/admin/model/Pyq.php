<?php
namespace app\admin\model;
use think\Model;
/*系统账号*/
class Pyq extends Common{
	
	
	public $pageSize = 10;
	public $orders = 'is_tj desc,id desc';
	public $modelTitle	= '朋友圈';
	public $searchField = array(['name'=>'title'],['name'=>'type_ids'],['name'=>'is_tj'],['name'=>'status']);
	
	public $listField	= array(
							//array('name'=>'id','title'=>'ID'),
							array('name'=>'type_ids','title'=>'类别'),
							array('name'=>'nickname','title'=>'昵称'),
							array('name'=>'headimgurl','title'=>'头像'),
							array('name'=>'title','title'=>'标题'),
							array('name'=>'zan_nums','title'=>'赞'),
							array('name'=>'pl_nums','title'=>'评论'),
							array('name'=>'view_nums','title'=>'查看'),
							array('name'=>'fx_nums','title'=>'分享'),
							array('name'=>'is_tj','title'=>'置顶'),
							array('name'=>'status','title'=>'状态'),
							array('name'=>'create_time','title'=>'发布时间')
						);
	/**
	 * 函数名	:_initialize
	 * 作用		:thinkphp Action的构造函数,用来初始化
	 * @return
	 */
	public function __construct(){
		parent::__construct();
		$this->imgList = true;
	}

	

	//列表编辑
   public function myFields(){
	   
	   $my_fields = array(
		    
			'is_tj' => array(
                'type' => 'radio',
                'name' => 'is_tj',
                'title' => '置顶',
                'validate' => '*',
                'dataKey' => 'common_bool',
            ) ,
			'type_ids' => array(
                'type' => 'checkbox',
                'name' => 'type_ids',
                'title' => '类别',
                'validate' => '*',
                'dataKey' => 'pyqtype',
            ) ,
			'title' => array(
                'type' => 'text',
                'name' => 'title',
                'title' => '标题',
                'validate' => '*'
            ) ,
			'nickname' => array(
                'type' => 'text',
                'name' => 'nickname',
                'title' => '昵称',
                'validate' => ''
            ) ,
			'headimgurl' => array(
                'type' => 'img',
                'name' => 'headimgurl',
                'title' => '头像',
                'validate' => ''
            ) ,
			'contents' => array(
                'type' => 'textarea',
                'name' => 'contents',
                'title' => '详情',
                'validate' => ''
            ) ,
			/*
			'o' => array(
                'type' => 'text',
                'name' => 'o',
                'title' => '排序',
                'validate' => 'n',
				'value'=>0
            ) ,
			*/
			
			'status' => array(
                'type' => 'radio',
                'name' => 'status',
                'title' => '状态',
                'validate' => '',
                'dataKey' => 'common_status',
				'value'=>1
            ) ,
			
		    
	   );
	  
	   return $my_fields;
   }


}