<?php
namespace app\admin\model;
use think\Model;

class Common extends Model{
	public $listWhere = array();
	public $orders = 'id desc';
	public $pageSize = 10;
	public $showWhere = array();
	public $editWhere = array();
	public $reloadUrl = '';
	public $indexUrl = '';
	public $indexTpl = false;
	public $dcTpl = false;
	public $addTpl = false;
	public $editTpl = false;
	public $showTpl = false;
	public $imgList = false;
	public $deleteWhere = array();
	public $rule = false;
	public $tableMy = false;
	
	/**
	 * 函数名	:_initialize
	 * 作用		:thinkphp Action的构造函数,用来初始化
	 * @return
	 */
	public function __construct(){
		parent::__construct();
	}
	//过滤数据（checkbox值组合，文件处理等）
   public function makeData($data,$fields){
	    foreach($data as $name=>$val){
			if(!isset($fields[$name])){
				continue;
			}
			$editType = $fields[$name]['type'];
			switch($editType){
				case 'checkbox'://复选框					
					$data[$name] = earr($val);
				break;
				case 'checkpicker'://复选框					
					$data[$name] = earr($val);
				break;
				case 'timestamp'://时间戳
					$data[$name] = strtotime($val);
				break;
			}
		}
		return $data;
   }

   //创建数据保留接口（如果需要则在子类中重写）
   public function createData($data){
		if(is_array($this->rule)){
			$data = checkrule($this->rule,$data);
		}
		return $data;
   }

   //添加数据保留接口（如果需要则在子类中重写）
   public function addData($data){
	    $data['create_time'] = time();
		$this->data($data);

		$result = $this->allowField(true)->save();
		if(!$result){
			return false;
		}
		return $this->id;
   }

   //创建更新数据保留接口（如果需要则在子类中重写）
   public function updateData($data){
	   	$data['update_time'] = time();
		if(is_array($this->rule)){
			$data = checkrule($this->rule,$data);
		}
		return $data;
   }
   //保存数据保留接口（如果需要则在子类中重写）
   public function saveData($data,$where){
		
		$result = $this->allowField(true)->save($data,$where);
		if(!$result){
			return false;
		}
		return true;
   }
   
   //添加、编辑数据之后的处理
   public function completeData($data,$fields){
		$fileField = array('img');
		$Tempfile = db('tempfile');
		foreach($data as $key=>$val){
			if(!isset($fields[$key])){
				continue;
			}
			$fieldType = $fields[$key]['type'];
			if(in_array($fieldType,$fileField)){
				$Tempfile->where(array('file_url'=>$val))->delete();
			}
		}
		return true;
   }
   //删除数据后的处理
   public function clearData($data,$fields,$tableName){
	    $fileField = array('img');
		foreach($data as $key=>$val){
			if(!isset($fields[$key])){
				continue;
			}
			$fieldType = $fields[$key]['type'];
			if(in_array($fieldType,$fileField)){
				
				unlink_my($val);
			}
		}
		
		$id = $data['id'];
		$imgLists = db('filelists')->where(array('pid'=>$id,'table_name'=>$tableName))->select();
		foreach($imgLists as $key=>$val){
			if(!isset($fields[$key])){
				continue;
			}
			$file_url = $val['file_url'];
			unlink_my($file_url);
		}
		db('filelists')->where(array('pid'=>$id,'table_name'=>$tableName))->delete();
		return true;
   }
}