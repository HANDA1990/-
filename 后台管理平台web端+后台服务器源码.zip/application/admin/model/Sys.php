<?php
namespace app\admin\model;
use think\Model;
/*系统账号*/
class Sys extends Common{
	public $pageSize = 10;
	public $orders = 'id desc';
	public $modelTitle	= '系统设置';
	public $searchField = array(  );
	
	public $listField	= array();
	/**
	 * 函数名	:_initialize
	 * 作用		:thinkphp Action的构造函数,用来初始化
	 * @return
	 */
	public function __construct(){
		parent::__construct();
		$this->editWhere = array('id'=>1);
		$this->showWhere = array('id'=>1);
		$this->reloadUrl = url('Sys/show');
	}

	

	//列表编辑
   public function myFields(){
	   
	   $my_fields = array(
		    
			
			
			
			'hf_nums' => array(
                'type' => 'text',
                'name' => 'hf_nums',
                'title' => '回复每小时限制',
                'validate' => '*',
            ) ,
			'glgjc' => array(
                'type' => 'textarea',
                'name' => 'glgjc',
                'title' => '过滤关键词(,隔开)',
                'validate' => '*',
            ) ,
			'title' => array(
                'type' => 'text',
                'name' => 'title',
                'title' => '系统名称',
                'validate' => '*',
            ) ,
			'link_man' => array(
                'type' => 'text',
                'name' => 'link_man',
                'title' => '联系人',
                'validate' => '',
            ) ,
			'telphone' => array(
                'type' => 'text',
                'name' => 'telphone',
                'title' => '客服电话',
                'validate' => '',
            ) ,
			'qq' => array(
                'type' => 'text',
                'name' => 'qq',
                'title' => 'QQ',
                'validate' => '',
            ) ,
			'email' => array(
                'type' => 'text',
                'name' => 'email',
                'title' => '邮箱',
                'validate' => '',
            ) ,
			'address' => array(
                'type' => 'text',
                'name' => 'address',
                'title' => '地址',
                'validate' => '*',
            ) ,
			'company_right' => array(
                'type' => 'text',
                'name' => 'company_right',
                'title' => '版权信息',
                'validate' => '*',
            ) ,
			'gzh_file_url' => array(
                'type' => 'img',
                'name' => 'gzh_file_url',
                'title' => '公众号二维码',
                'validate' => '',
            ) ,
			'contents' => array(
                'type' => 'editor',
                'name' => 'contents',
                'title' => '系统介绍(PC)',
                'validate' => '*',
            ) ,
			'app_contents' => array(
                'type' => 'editor',
                'name' => 'app_contents',
                'title' => '系统介绍(手机)',
                'validate' => '*',
            ) ,
			'zc_contents' => array(
                'type' => 'editor',
                'name' => 'zc_contents',
                'title' => '注册协议',
                'validate' => '*',
            ) ,
			
			
		    
	   );
	  
	   return $my_fields;
   }


}