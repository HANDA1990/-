<?php
namespace app\admin\model;
use think\Model;
/*系统账号*/
class Access extends Common{
	public $pageSize = 100;
	public $orders = 'pid asc,o desc,id asc';
	public $searchField	= array( array('name'=>'title','trueField'=>'title'),array('name'=>'pid'));
	public $modelTitle	= '菜单管理';

	
	public $listField	= array(
							//array('name'=>'id','title'=>'ID'),
							array('name'=>'type_id','title'=>'归属'),
							array('name'=>'pid','title'=>'类别'),					
							array('name'=>'file_url','title'=>'图标'),				
							array('name'=>'i_class','title'=>'图标样式'),
							array('name'=>'title','title'=>'名称'),		
							array('name'=>'ma','title'=>'模块'),
							array('name'=>'admin_status','title'=>'超级管理员可见'),
							//array('name'=>'create_time','title'=>'发布时间')
						);
	/**
	 * 函数名	:_initialize
	 * 作用		:thinkphp Action的构造函数,用来初始化
	 * @return
	 */
	public function __construct(){
		parent::__construct();
	}



	//列表编辑
   public function myFields(){
	   
	   $my_fields = array(
		    'type_id' => array(
                'type' => 'radio',
                'name' => 'type_id',
                'title' => '类型',
                'validate' => '*',
                'dataKey' => 'access_type_id',
            ) ,
		   
			'pid' => array(
                'type' => 'select',
                'name' => 'pid',
                'title' => '归属',
                'validate' => '',
                'dataKey' => 'access_pid',
            ) ,
			
			'file_url' => array(
                'type' => 'img',
                'name' => 'file_url',
                'title' => '图标',
                'validate' => ''
            ) ,
			'i_class' => array(
                'type' => 'text',
                'name' => 'i_class',
                'title' => '图标样式',
                'validate' => ''
            ) ,
			'title' => array(
                'type' => 'text',
                'name' => 'title',
                'title' => '名称',
                'validate' => '*'
            ) ,
			'ma' => array(
                'type' => 'text',
                'name' => 'ma',
                'title' => '模块',
                'validate' => '*'
            ) ,
			'admin_status' => array(
                'type' => 'radio',
                'name' => 'admin_status',
                'title' => '超级管理员可见',
                'validate' => '',
                'dataKey' => 'common_bool',
				'value'=>1
            ) ,
			
		    
	   );
	  
	   return $my_fields;
   }


}