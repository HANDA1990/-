<?php
namespace app\admin\model;
use think\Model;
/*系统账号*/
class Admin extends Common{
	public $indexTpl = 'admin:index';
	public $pageSize = 10;
	public $orders = 'id desc';
	public $modelTitle	= '后台账号';
	public $searchField	= array( array('name'=>'account') );
	public $rule =    [ 'admin_type_id|账号类型'  => 'require|between:1,10',
						'account|账号'  => 'require|max:20',
					];
	
	public $listField	= array(
							//array('name'=>'id','title'=>'ID'),
							array('name'=>'account','title'=>'账号'),
							
							array('name'=>'admin_type_id','title'=>'类别'),
							array('name'=>'file_url','title'=>'头像'),
							array('name'=>'title','title'=>'姓名'),
							array('name'=>'phone','title'=>'手机'),
							array('name'=>'status','title'=>'状态'),
							//array('name'=>'create_time','title'=>'发布时间')
						);
	/**
	 * 函数名	:_initialize
	 * 作用		:thinkphp Action的构造函数,用来初始化
	 * @return
	 */
	public function __construct(){
		parent::__construct();
		$adminInfo = admininfo();		
		$type_id = $adminInfo['admin_type_id'];
		if($type_id!=1){
			//非超级管理员
			$FIELD_DATA = config('FIELD_DATA');
			$admin_type = $FIELD_DATA['admin_type'];
			$admin_type['dataList']['where'] = array('status'=>1,'id'=>array('in',array(3,4)));
			$FIELD_DATA['admin_type'] = $admin_type;
			config('FIELD_DATA',$FIELD_DATA);

			$this->listWhere = array('admin_type_id'=>array('in',array(3,4)));
			
		}
	}

	//创建数据保留接口（如果需要则在子类中重写）
   public function createData($data){
		$type_id = $data['admin_type_id'];
		$account = $data['account'];

		$data['password'] = def_password();
		
		if(is_array($this->rule)){
			$data = checkrule($this->rule,$data);
		}
		if(is_array($data)){
			$account = $data['account'];
			$have = $this->where( array('account'=>$account) )->find();
			if($have){
				return '账号已存在';
			}
		}
		return $data;
   }
   //添加数据保留接口（如果需要则在子类中重写）
   public function addData($data){
	    $data['create_time'] = time();
		$this->data($data);

		$result = $this->allowField(true)->save();
		if(!$result){
			return false;
		}
		return $this->id;
   }
   //创建更新数据保留接口（如果需要则在子类中重写）
   public function updateData($data){
	   	$data['update_time'] = time();
		if(is_array($this->rule)){
			$data = checkrule($this->rule,$data);
		}
		
		return $data;
   }
   //保存数据保留接口（如果需要则在子类中重写）
   public function saveData($data,$where){
		
		$result = $this->allowField(true)->save($data,$where);
		if(!$result){
			return false;
		}
		if($data['yey_id']>0){
			addaygl($where['id'],$data['yey_id']);
		}
		return true;
   }

	//列表编辑
   public function myFields(){
	   
	   $my_fields = array(
		    'account' => array(
                'type' => 'text',
                'name' => 'account',
                'title' => '账号',
                'validate' => '*',
				'edit'	=> 2
            ) ,
		   
			'admin_type_id' => array(
                'type' => 'radio',
                'name' => 'admin_type_id',
                'title' => '类别',
                'validate' => '*',
                'dataKey' => 'admin_type',
				'edit'	=>2,
				'value'=>1
            ) ,
			
			'file_url' => array(
                'type' => 'img',
                'name' => 'file_url',
                'title' => '头像',
                'validate' => ''
            ) ,
			'title' => array(
                'type' => 'text',
                'name' => 'title',
                'title' => '姓名',
                'validate' => '*'
            ) ,
			'phone' => array(
                'type' => 'text',
                'name' => 'phone',
                'title' => '手机号',
                'validate' => 'n11-11'
            ) ,
			'email' => array(
                'type' => 'text',
                'name' => 'email',
                'title' => '邮箱',
                'validate' => ''
            ) ,
			'address' => array(
                'type' => 'text',
                'name' => 'address',
                'title' => '地址',
                'validate' => ''
            ) ,
			
			'status' => array(
                'type' => 'radio',
                'name' => 'status',
                'title' => '状态',
                'validate' => '',
                'dataKey' => 'common_status',
				'edit'	=>2,
				'value'=>1
            ) ,
			
		    
	   );
	  
	   return $my_fields;
   }


}