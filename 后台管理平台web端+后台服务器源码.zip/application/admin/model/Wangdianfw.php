<?php
namespace app\admin\model;
use think\Model;
/*系统账号*/
class Wangdianfw extends Common{
	
	
	public $pageSize = 10;
	public $orders = 'o asc,id desc';
	public $modelTitle	= '网点服务内容';
	public $searchField = array( ['name'=>'wangdian_id'] );
	
	public $listField	= array(
							//array('name'=>'id','title'=>'ID'),
							array('name'=>'wangdian_id','title'=>'服务网点'),
							array('name'=>'title','title'=>'标题'),
							array('name'=>'yy_times','title'=>'时间'),
							array('name'=>'price','title'=>'价格'),
							array('name'=>'o','title'=>'排序'),
							array('name'=>'status','title'=>'状态'),
							//array('name'=>'create_time','title'=>'发布时间')
						);
	/**
	 * 函数名	:_initialize
	 * 作用		:thinkphp Action的构造函数,用来初始化
	 * @return
	 */
	public function __construct(){
		parent::__construct();
		
	}

	

	//列表编辑
   public function myFields(){
	   
	   $my_fields = array(
		   
			'wangdian_id' => array(
                'type' => 'radio',
                'name' => 'wangdian_id',
                'title' => '网点',
                'validate' => '',
                'dataKey' => 'wangdian_id'
            ) ,
			
			'title' => array(
                'type' => 'text',
                'name' => 'title',
                'title' => '标题',
                'validate' => '*'
            ) ,
			'yy_times' => array(
                'type' => 'text',
                'name' => 'yy_times',
                'title' => '时间',
                'validate' => '*'
            ) ,
			'price' => array(
                'type' => 'text',
                'name' => 'price',
                'title' => '价格',
                'validate' => '*'
            ) ,
			
			'danwei' => array(
                'type' => 'text',
                'name' => 'danwei',
                'title' => '收费单位',
                'validate' => '*'
            ) ,
			
			'o' => array(
                'type' => 'text',
                'name' => 'o',
                'title' => '排序',
                'validate' => 'n',
				'value'=>0
            ) ,
			
			
			'status' => array(
                'type' => 'radio',
                'name' => 'status',
                'title' => '状态',
                'validate' => '',
                'dataKey' => 'common_status',
				'value'=>1
            ) ,
			
		    
	   );
	  
	   return $my_fields;
   }


}