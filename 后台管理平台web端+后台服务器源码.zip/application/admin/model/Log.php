<?php
namespace app\admin\model;
use think\Model;
/*系统账号*/
class Log extends Common{
	public $pageSize = 10;
	public $orders = 'id desc';
	public $modelTitle	= '操作日志';
	public $searchField	= array( array('name'=>'ma','trueField'=>'ma|http_url|get_json|post_json'),array('name'=>'admin_id'),array('name'=>'ip') );
	
	public $listField = array(
        array('name'=>'id','title'=>'ID'),
		
        array(
            'name' => 'ma',
            'title' => '操作'
        ) ,
		array(
            'name' => 'admin_id',
            'title' => '账号'
        ) ,
		
        array(
            'name' => 'http_url',
            'title' => '链接'
        ) ,	
        array(
            'name' => 'ip',
            'title' => 'IP'
        ) ,	
        array(
            'name' => 'create_time',
            'title' => '时间'
        ) ,
       
        
    );
	/**
	 * 函数名	:_initialize
	 * 作用		:thinkphp Action的构造函数,用来初始化
	 * @return
	 */
	public function __construct(){
		parent::__construct();
		
	}

	

	//列表编辑
   public function myFields(){
	   
	   $my_fields = array(
		   
			'admin_id' => array(
                'type' => 'select',
                'name' => 'admin_id',
                'title' => '账号',
                'validate' => 'required',				
                'add' => 0,			
                'edit' => 2,
				'dataKey' => 'admin_id_account_db',
            ) ,
			'ma' => array(
                'type' => 'text',
                'name' => 'ma',
                'title' => '操作',
                'validate' => 'required',				
                'add' => 0,			
                'edit' => 2,
            ) ,
			'http_url' => array(
                'type' => 'text',
                'name' => 'http_url',
                'title' => '链接',
                'validate' => 'required',				
                'add' => 0,			
                'edit' => 2,
            ) ,
			'http_url_from' => array(
                'type' => 'text',
                'name' => 'http_url_from',
                'title' => '来源链接',
                'validate' => 'required',				
                'add' => 0,			
                'edit' => 2,
            ) ,
			'get_json' => array(
                'type' => 'text',
                'name' => 'get_json',
                'title' => 'get数据',
                'validate' => 'required',				
                'add' => 0,			
                'edit' => 2,
            ) ,
			'post_json' => array(
                'type' => 'text',
                'name' => 'post_json',
                'title' => 'post数据',
                'validate' => 'required',				
                'add' => 0,			
                'edit' => 2,
            ) ,
			'session_json' => array(
                'type' => 'text',
                'name' => 'session_json',
                'title' => 'session数据',
                'validate' => 'required',				
                'add' => 0,			
                'edit' => 2,
            ) ,
			'ip' => array(
                'type' => 'text',
                'name' => 'ip',
                'title' => 'IP',
                'validate' => 'required',				
                'add' => 0,			
                'edit' => 2,
            ) ,
            'create_time' => array(
                'type' => 'timestamp',
                'name' => 'create_time',
                'title' => '创建时间',
                'validate' => 'required',
				'dataformat' => 'Y-m-d H:i',
				'step'=>5,
				//'min'=>'2016/01/06',
				//'max'=>'2016/03/06',
				'value'=>time(),
				'edit'=>2
            ) ,
			
	   );
	  
	   return $my_fields;
   }


}