<?php
namespace app\admin\model;
use think\Model;
/*系统账号*/
class Banner extends Common{
	
	
	public $pageSize = 10;
	public $orders = 'o asc,id asc';
	public $modelTitle	= '广告图';
	public $searchField = array();
	
	public $listField	= array(
							//array('name'=>'id','title'=>'ID'),
							array('name'=>'type_id','title'=>'类型'),
							array('name'=>'file_url','title'=>'图片'),
							array('name'=>'title','title'=>'介绍'),
							array('name'=>'status','title'=>'状态'),
							//array('name'=>'create_time','title'=>'发布时间')
						);
	/**
	 * 函数名	:_initialize
	 * 作用		:thinkphp Action的构造函数,用来初始化
	 * @return
	 */
	public function __construct(){
		parent::__construct();
		
	}

	

	//列表编辑
   public function myFields(){
	   
	   $my_fields = array(
		    
			
			'type_id' => array(
                'type' => 'radio',
                'name' => 'type_id',
                'title' => '类型',
                'validate' => '',
                'dataKey' => 'banner_type_id',
				'value'=>1
            ) ,
			'file_url' => array(
                'type' => 'img',
                'name' => 'file_url',
                'title' => '图片',
                'validate' => ''
            ) ,
			'title' => array(
                'type' => 'text',
                'name' => 'title',
                'title' => '介绍',
                'validate' => '*'
            ) ,
			
			'http_url' => array(
                'type' => 'text',
                'name' => 'http_url',
                'title' => '链接地址',
                'validate' => ''
            ) ,
			
			
			'status' => array(
                'type' => 'radio',
                'name' => 'status',
                'title' => '状态',
                'validate' => '',
                'dataKey' => 'common_status',
				'value'=>1
            ) ,
			
		    
	   );
	  
	   return $my_fields;
   }


}