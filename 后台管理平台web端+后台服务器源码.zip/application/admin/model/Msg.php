<?php
namespace app\admin\model;
use think\Model;
/*系统账号*/
class Msg extends Common{
	public $pageSize = 10;
	public $orders = 'id desc';
	public $modelTitle	= '留言反馈';
	public $searchField = array( array('name'=>'type_id'),array('name'=>'status'),array('name'=>'contents'),array('name'=>'phone')  );
	
	public $listField	= array(
							//array('name'=>'id','title'=>'ID'),
							array('name'=>'type_id','title'=>'类型'),
							array('name'=>'phone','title'=>'联系方式'),
							array('name'=>'contents','title'=>'内容'),
							array('name'=>'status','title'=>'状态'),
							array('name'=>'create_time','title'=>'反馈时间')
						);
	/**
	 * 函数名	:_initialize
	 * 作用		:thinkphp Action的构造函数,用来初始化
	 * @return
	 */
	public function __construct(){
		parent::__construct();
		
	}

	

	//列表编辑
   public function myFields(){
	   
	   $my_fields = array(
		    
			
			
			'type_id' => array(
                'type' => 'radio',
                'name' => 'type_id',
                'title' => '类型',
                'validate' => '',
                'dataKey' => 'fk_type',
				'edit'	=>2
            ) ,
			'phone' => array(
                'type' => 'text',
                'name' => 'phone',
                'title' => '联系电话',
                'validate' => '*',				
				'edit'	=>2
            ) ,
			
			'contents' => array(
                'type' => 'textarea',
                'name' => 'contents',
                'title' => '内容',
                'validate' => '*',				
				'edit'	=>2
            ) ,
			
			
			'status' => array(
                'type' => 'radio',
                'name' => 'status',
                'title' => '状态',
                'validate' => '',
                'dataKey' => 'common_status_cl'
            ) ,
			
		    
	   );
	  
	   return $my_fields;
   }


}