<?php
namespace app\admin\model;
use think\Model;
/*系统账号*/
class Wtbd extends Common{
	
	
	public $pageSize = 10;
	public $orders = 'id desc';
	public $modelTitle	= '朋友圈';
	public $searchField = array(['name'=>'nickname'],['name'=>'ylsj_json']);
	
	public $listField	= array(
							//array('name'=>'id','title'=>'ID'),
							array('name'=>'nickname','title'=>'昵称'),
							array('name'=>'headimgurl','title'=>'头像'),
							array('name'=>'ylsj_json','title'=>'详情'),
							array('name'=>'status','title'=>'状态'),
							array('name'=>'create_time','title'=>'发布时间')
						);
	/**
	 * 函数名	:_initialize
	 * 作用		:thinkphp Action的构造函数,用来初始化
	 * @return
	 */
	public function __construct(){
		parent::__construct();
		$this->showTpl = "wtbd:show";
		
	}

	

	//列表编辑
   public function myFields(){
	   
	   $my_fields = array(
		    
			
			
			'nickname' => array(
                'type' => 'text',
                'name' => 'nickname',
                'title' => '昵称',
                'validate' => ''
            ) ,
			'headimgurl' => array(
                'type' => 'img',
                'name' => 'headimgurl',
                'title' => '头像',
                'validate' => ''
            ) ,
			'ylsj_json' => array(
                'type' => 'textarea',
                'name' => 'ylsj_json',
                'title' => '详情',
                'validate' => ''
            ) ,
			/*
			'o' => array(
                'type' => 'text',
                'name' => 'o',
                'title' => '排序',
                'validate' => 'n',
				'value'=>0
            ) ,
			*/
			
			'status' => array(
                'type' => 'radio',
                'name' => 'status',
                'title' => '状态',
                'validate' => '',
                'dataKey' => 'common_status',
				'value'=>1
            ) ,
			
		    
	   );
	  
	   return $my_fields;
   }


}