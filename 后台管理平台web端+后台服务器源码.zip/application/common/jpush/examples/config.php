<?php
require __DIR__ . '/../autoload.php';

use JPush\Client as JPush;

$app_key = 'c3fa035a6818528f6f9d3b01';//getenv('c3fa035a6818528f6f9d3b01');
$master_secret = 'c9f9b2c3a96a2da7388a995c';//getenv('c9f9b2c3a96a2da7388a995c');
$registration_id = '';//getenv('registration_id');

$client = new JPush($app_key, $master_secret);
