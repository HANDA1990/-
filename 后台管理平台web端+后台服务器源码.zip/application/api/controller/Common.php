<?php
namespace app\api\controller;
class Common 
{	
	public $baseHtml = '';
	public $from = '';
	public $baseUrl = 'http://szx.yshdszx.com';
	/**
	 * 函数名	:__construct
	 * 作用		:cotroller构造函数
	 * @return
	 */
   public function __construct() {
	   if(file_exists('runlog/ajax.html')){
			$filesize = filesize('runlog/ajax.html')/1024;
			if($filesize>500){
				unlink('runlog/ajax.html');
			}
	   }
		//$wxInfo = ['unionid'=>'djfj8hjhsdfo','openid'=>'34544dsfadfjalfj','headimgurl'=>'https://t.idianjiao.com/djedu/img/logo1.png','nickname'=>'壹生互动'];
		//session(config('WX_KEY'),$wxInfo);
		
	    header("Content-type:text/html;charset=utf-8");
	    $this->controllerName = strtolower(request()->controller());
		$this->actionName = strtolower(request()->action());

		$get = gwhere();
		$this->from = $get['from'];
		
		
		

		$this->getData();
		

		//秘钥验证
		
		$keystr = strtolower($get['keystr']);
		$dataStr = $this->dataStr;
		$jmstr = $dataStr.'nimdaae'.$this->actionName.date('Ymd');
		$md5str = md5($jmstr);


			file_put_contents('runlog/ajax.html', '访问接口：'.$this->actionName.PHP_EOL, FILE_APPEND);
			file_put_contents('runlog/ajax.html', 'URL参数：'.json_encode($get).PHP_EOL, FILE_APPEND);
			file_put_contents('runlog/ajax.html', '加密字符串：'.$jmstr.PHP_EOL, FILE_APPEND);
			file_put_contents('runlog/ajax.html', 'md5str：'.$md5str.PHP_EOL, FILE_APPEND);
			file_put_contents('runlog/ajax.html', '访问时间：'.date('Y-m-d H:i:s').PHP_EOL, FILE_APPEND);
			file_put_contents('runlog/ajax.html', '客户端数据：'.$this->dataStr.PHP_EOL, FILE_APPEND);
			//file_put_contents('runlog/ajax.html', 'server：'.json_encode($_SERVER).PHP_EOL, FILE_APPEND);

		if($keystr!='defualtencryption' && $this->from!='get' && !in_array($this->actionName,array('docs','datalog')) ){
			if($keystr!=$md5str ){
				//return $this->resultReturn(false, '秘钥验证失败');
			}
		}
		
		
		//d89b110c4907c37583b96c969a5ac350
		//wx0b7aa39e5e246fbd
		$this->cW();
		

		$this->cL();
		
		
   }
   //微信验证
   public function cW(){
		if(!isWeixin()){
			return true;
		} 
		$unCheckController = array('weixin','publics');
		if(in_array($this->controllerName,$unCheckController)){
			
			return true;
		}
		$unCheckAction = array('sendverf','xcxdl','wxjs','fxcgnum');
		if(in_array($this->actionName,$unCheckAction)){
			return true;
		}
		
		$wxInfo = session(config('WX_KEY'));
		$openid = $wxInfo['openid'];
		if($openid){
			return true;
		}
					//开始获取微信信息
					$REDIRECT_URI = url('Weixin/getwxuserinfo',array(),'',true);
					$set_url = session('set_url');					
					$tourl = $set_url ? $set_url : $_SERVER['HTTP_REFERER'];
					session('tourl',$tourl);
					
					$url = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid='.config('WX_AID').'&redirect_uri='.$REDIRECT_URI.'&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect';
					
		return $this->resultReturn(false, '','',0,$url);
   }
   
   //登录验证
   public function cL(){
	   
		$unCheckController = array('weixin','publics');
		if(in_array($this->controllerName,$unCheckController)){
			
			return true;
		}
		
		$unCheckAction = array('sendverf','companyinfo','infopage','index','sysinfo','reg','login','verflogin','resetpass','cv','docs','datalog','indexinfo','keys','words','news','newsinfo','huodong','huodonginfo','articlescz','articlespl','articlespllists','articlespldel','upfile','upfilelists','fbpyq','pyq','pyqinfo','pyqdel','wtbd','xcxdl','fxcg','httprq','wxjs','fxcgnum','djkf');
		if(in_array($this->actionName,$unCheckAction)){
			return true;
		}
		
		$userInfo = gU();
		$userId = $userInfo['id'];
		//$userId = session(config('ACCOUNT_KEY'));
		if(!$userId){
			//未登录
			return $this->resultReturn(false, 'loginerr');
		}

   }
	protected function getData() {
		/*
		$from = $this->from;
		if($from=='ajax'){
			$data = input('post.');
			$this->Data = $data;
			return $data;
		}elseif($from=='get'){
			$data = gwhere();
			$this->Data = $data;
			return $data;
		}else{
			$dataStr = file_get_contents('php://input');
			$this->dataStr = $dataStr;
			$this->Data = json_decode($dataStr,true);
		}
		*/

		$from = $this->from;
		if($from=='ajax'){
			$data = input('post.');
		}elseif($from=='get'){
			$data = gwhere();
		}else{
			$dataStr = file_get_contents('php://input');
			$this->dataStr = $dataStr;
			$data = json_decode($dataStr,true);
		}

		$actionName = $this->actionName;
		$checkArr = array('fbpyq','articlespl');
		if(in_array($actionName,$checkArr)){
			$data = array_map("mgcr",$data);
		}		
		$this->Data = $data;
		return $this->Data;
		
    }

	

   /**
     * { status : true, info: $info}
     * @param  string $info
     * @param  string $url
     * @return
	 success($msg = '', $url = null, $data = '', $wait = 3, array $header = [])
     */
    protected function successReturn( $info='',$data='',$counts=0) {
	   return $this->resultReturn(true, $info,$data,$counts);
    }

    /**
     * { status : false, info: $info}
     * @param  string $info
     * @param  string $url
     * @return
     */
    protected function errorReturn( $info='',$data='',$counts=0) {
    
		return $this->resultReturn(false, $info,$data,$counts);
    }
	

	/**
     * 返回带有status、info键值的json数据
     * @param  boolean $status
     * @param  string $info
     * @param  string $url
     * @return
     */

    protected function resultReturn($status, $info='',$data='',$counts=0,$url='') {
			$json = array();
			$json['retInt'] = $status ? 1 : 0;
			$json['retErr'] = $info;
			$json['retRes'] = $data;
			$json['retCounts'] = (int)$counts;
			$json['retUrl'] = $url;

			if($this->from=='get'){
				print_r($json);
			}
			
			$returnStr = json_encode($json);
			//file_put_contents('runlog/ajax.html', '返回：'.$returnStr.PHP_EOL, FILE_APPEND);
			//file_put_contents('runlog/ajax.html', '返回数据：'.$returnStr.PHP_EOL, FILE_APPEND);
			//file_put_contents('runlog/ajax.html', '当前SESSION：'.json_encode($_SESSION).PHP_EOL, FILE_APPEND);
			//file_put_contents('runlog/ajax.html', '当前COOKIE：'.json_encode($_COOKIE).PHP_EOL, FILE_APPEND);
			file_put_contents('runlog/ajax.html', '__________________________________________________'.PHP_EOL, FILE_APPEND);
			
			
			
			

			//header('Access-Control-Allow-Origin: *');
			//header('Access-Control-Allow-Methods: POST');
			//header('Access-Control-Max-Age: 1000');
			//替换upload路径
			//$returnStr = str_replace(':"upload\/',':"\/upload\/',$returnStr);
			$returnStr = str_replace(':null',':""',$returnStr);
			
			echo $returnStr;exit;

    }

}
