<?php
namespace app\api\controller;
class Index extends Common
{	
	public function keys(){
		$return = array('prefs:root=WIFI','App-Prefs:root=WIFI');
		return $this->successReturn('',$return);
	}
	public function datalog(){
		$where = array('card_type'=>'PF');
		$lists = db('datalog')->where($where)->limit(0,100)->order('id desc')->select();

		return view('datalog',['lists'=>$lists]);
	}
    public function index(){
		$cacheKey = md5('TR-005D148100164020C34E974B31');
		var_dump(cache($cacheKey));
		exit;
		return view();
    }
	public function docs(){
		return view();
    }
	//名词库
	public function words(){
		$lists = db('words')->where(['status'=>1])->cache(true)->select();
		$return = array();
		foreach($lists as $key=>$val){
			$return[$val['key']] = $val['value'];
		}
		return $this->successReturn('',$return);
	}
	//操作说明列表
	public function czsm(){
		$Model = db('czsm');
		$lists = $Model->where( array('status'=>1) )->order('o desc,id asc')->field('id,title,file_url,sub_title,app_contents')->select();
		return $this->successReturn('',$lists);
	}
	//操作说明详情
	public function czsminfo(){
		$id = $this->Data['id'];
		$Model = db('czsm');
		$info = $Model->where( array('status'=>1,'id'=>$id) )->field('id,title,file_url,sub_title,app_contents')->find();
		if(!$info){
			return $this->errorReturn('未找到内容');
		}
		$info['app_contents'] = $this->baseHtml.$info['app_contents'];
		return $this->successReturn('',$info);
	}
	//养鱼日志
	public function yyrz(){
		$userInfo = gU();
		$userId = $userInfo['id'];
		
		$pagesize = $this->Data['page_size'];
		$page = $this->Data['page'];
		$page = $page>0 ? $page : 1;
		$pagesize = $pagesize>0 ? $pagesize : 20;
		
		$where = array('status'=>1,'account_id'=>$userId);
		$Model = db('yyrz');
		$counts = $Model->where($where)->count();
		$start = ($page-1)*$pagesize;
		$limit = $start.','.$pagesize;

		$lists = $Model->where( $where )->order('id desc')->field('id,title,sub_title,create_time,img_file_urls')->limit($limit)->select();
		foreach($lists as $key=>$val){
			$img_file_urls = json_decode($val['img_file_urls'],true);
			$lists[$key]['file_url'] = show_resize($img_file_urls[0]);
			unset($lists[$key]['img_file_urls']);
		}
		return $this->successReturn('',$lists,$counts);
	}
	//养鱼日志详情
	public function yyrzinfo(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$id = $this->Data['id'];
		$Model = db('yyrz');
		$info = $Model->where( array('status'=>1,'id'=>$id) )->find();
		if(!$info){
			return $this->errorReturn('未找到内容');
		}

		$info['img_file_urls'] = json_decode($info['img_file_urls'],true);
		return $this->successReturn('',$info);
	}
	//提交养鱼日志
	public function tjyyrz(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$title = $this->Data['title'];
		$contents = $this->Data['contents'];
		$img_file_urls = $this->Data['img_file_urls'];
		if(!$title || !$contents){
			return $this->errorReturn('参数错误');
		}
		if(!is_array($img_file_urls) || !count($img_file_urls)){
			return $this->errorReturn('请上传一张图片');
		}

		$Model = db('yyrz');
		$data = array(
					'account_id'=>$userId,
					'title'=>$title,
					'sub_title'=>mb_substr($contents,0,30,'UTF-8'),
					'contents'=>$contents,
					'create_time'=>time()
				);
		if(is_array($img_file_urls) && count($img_file_urls)){
			$tempArr = array();
			foreach($img_file_urls as $file_url){
				db('Tempfile')->where( array('file_url'=>$file_url) )->delete();
				if(file_exists($file_url)){
					$tempArr[] = $file_url;					
				}
			}
			$data['img_file_urls'] = json_encode($tempArr);
		}

		$result = $Model->insertGetId($data);
		if(!$result){
			return $this->errorReturn('操作失败');
		}
		return $this->successReturn('操作成功');
	}
	//删除养鱼日志
	public function delyyrz(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$id = $this->Data['id'];
		$Model = db('yyrz');
		$result = $Model->where( array('account_id'=>$userId,'id'=>$id) )->delete();
		if(!$result){
			return $this->errorReturn('操作失败');
		}
		return $this->successReturn('操作成功');
	}
	//厂家列表
	public function changjia(){

		$pagesize = $this->Data['page_size'];
		$page = $this->Data['page'];
		$page = $page>0 ? $page : 1;
		$pagesize = $pagesize>0 ? $pagesize : 20;
		
		$where = array('status'=>1);
		$title = $this->Data['title'];
		if($title){
			$where['title|sub_title'] = array('like',"%{$title}%");
		}

		$Model = db('changjia');
		$counts = $Model->where($where)->count();
		$start = ($page-1)*$pagesize;
		$limit = $start.','.$pagesize;

		
		$lists = $Model->where( $where )->order('o desc,id desc')->field('id,title,file_url,sub_title,address')->limit($limit)->select();
		return $this->successReturn('',$lists,$counts);
	}
	//厂家详情
	public function changjiainfo(){
		$id = $this->Data['id'];
		$Model = db('changjia');
		$info = $Model->where( array('status'=>1,'id'=>$id) )->field('id,title,file_url,address,sub_title,app_contents')->find();
		if(!$info){
			return $this->errorReturn('未找到内容');
		}

		$info['app_contents'] = $this->baseHtml.$info['app_contents'];
		return $this->successReturn('',$info);
	}
	
	//网点列表
	public function wangdian(){

		$pagesize = $this->Data['page_size'];
		$page = $this->Data['page'];
		$page = $page>0 ? $page : 1;
		$pagesize = $pagesize>0 ? $pagesize : 20;
		
		$where = array('status'=>1);
		$title = $this->Data['title'];
		$lng = $this->Data['lng'] ? $this->Data['lng'] : 0;
		$lat = $this->Data['lat'] ? $this->Data['lat'] : 0;
		if($title){
			$where['title|sub_title'] = array('like',"%{$title}%");
		}

		$Model = db('wangdian');
		$counts = $Model->where($where)->count();
		$start = ($page-1)*$pagesize;
		$limit = $start.','.$pagesize;

		
		$lists = $Model->where( $where )->order('o desc,id desc')->field("id,title,file_url,sub_title,address,xingji,lng,lat,(6378.138 * 2 * asin(sqrt(pow(sin((lat * pi() / 180 - ".$lat." * pi() / 180) / 2),2) + cos(lat * pi() / 180) * cos(".$lat." * pi() / 180) * pow(sin((lng * pi() / 180 - ".$lng." * pi() / 180) / 2),2))) * 1000) as jl")->limit($limit)->order('jl asc')->select();
		foreach($lists as $key=>$val){
			$jl = $val['jl'];
			if($jl<1000){
				$jl = (int)$jl;
				$dw = 'm';
			}else{
				$jl = show_price($jl/1000);
				$dw = 'km';
			}
			$lists[$key]['jl'] = $jl.$dw;
		}
	
		return $this->successReturn('',$lists,$counts);
	}
	//网点详情
	public function wangdianinfo(){
		$id = $this->Data['id'];
		$lng = $this->Data['lng'] ? $this->Data['lng'] : 0;
		$lat = $this->Data['lat'] ? $this->Data['lat'] : 0;

		$Model = db('wangdian');
		$info = $Model->where( array('status'=>1,'id'=>$id) )->field('id,title,file_url,address,sub_title,app_contents,xingji,lng,lat,(6378.138 * 2 * asin(sqrt(pow(sin((lat * pi() / 180 - ".$lat." * pi() / 180) / 2),2) + cos(lat * pi() / 180) * cos(".$lat." * pi() / 180) * pow(sin((lng * pi() / 180 - ".$lng." * pi() / 180) / 2),2))) * 1000) as jl')->find();
		if(!$info){
			return $this->errorReturn('未找到网点');
		}
		$info['app_contents'] = $this->baseHtml.$info['app_contents'];
		
			$jl = $info['jl'];
			if($jl<1000){
				$jl = (int)$jl;
				$dw = 'm';
			}else{
				$jl = show_price($jl/1000);
				$dw = 'km';
			}
			$info['jl'] = $jl.$dw;
		//服务列表
		$fw_lists = db('wangdianfw')->where(['wangdian_id'=>$id,'status'=>1])->order('o desc,id asc')->field('id,title,price,danwei,yy_times')->select();
		$info['fw_lists'] = $fw_lists;
		return $this->successReturn('',$info);
	}
	//最新消息
	public function newnews(){	
		$times = $this->Data['times'];		
		if($times){
			$time_limit = $times;
		}else{
			$time_limit = time()-20*60;
		}
		$where = array('status'=>1,'create_time'=>array('gt',$time_limit));
		

		$Model = db('news');
		
		$lists = $Model->where( $where )->order('o desc,id desc')->field('id,title,create_time')->limit('0,5')->select();
		return $this->successReturn('',$lists);
	}
	//消息列表
	public function news(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$pagesize = $this->Data['page_size'];
		$page = $this->Data['page'];
		$page = $page>0 ? $page : 1;
		$pagesize = $pagesize>0 ? $pagesize : 20;
		
		$where = array('status'=>1);
		$title = $this->Data['title'];
		if($title){
			$where['title|sub_title'] = array('like',"%{$title}%");
		}

		$Model = db('news');
		$counts = $Model->where($where)->count();
		$start = ($page-1)*$pagesize;
		$limit = $start.','.$pagesize;

		
		$lists = $Model->where( $where )->order('o desc,id desc')->field('id,title,file_url,sub_title,create_time')->limit($limit)->select();
		foreach($lists as $key=>$val){
			$is_read = db('newsyd')->where(['news_id'=>$val['id'],'account_id'=>$userId])->value('id');
			$lists[$key]['is_read'] = $is_read ? 1 : 0;
		}
		return $this->successReturn('',$lists,$counts);
	}
	//消息详情
	public function newsinfo(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$id = $this->Data['id'];
		$Model = db('news');
		$info = $Model->where( array('status'=>1,'id'=>$id) )->field('id,title,file_url,sub_title,app_contents,create_time')->find();
		if(!$info){
			return $this->errorReturn('未找到内容');
		}
		$info['app_contents'] = $this->baseHtml.$info['app_contents'];

		db('newsyd')->insert(['account_id'=>$userId,'news_id'=>$info['id']]);
		return $this->successReturn('',$info);
	}
	//获取微信js配置参数
	public function wxjs(){
		$Wx = new \think\Weixin('isme',config('WX_AID'),config('WX_AST') );
		$url = $_SERVER['HTTP_REFERER'];//'http://dj.ibei360.cn/wxsm.html';
		
		$jsConfig = $Wx->getJsApiConf($url);
		return $this->successReturn('',$jsConfig);
	}
	//小程序登录
	public function xcxdl(){
		$data = gwhere();
		/*
		print_r($data);

		$openid = '4444444444444';
		$unionid = '444444444797979';
		$headimgurl = 'https://t.idianjiao.com/djedu/img/logo1.png';
		$nickname = '壹生互动';
		$tourl = 'http://szx.yshdszx.com/xcxtg/index.html?id=123&sadd=bbb';
		
		$urlData = ['unionid'=>$unionid,'openid'=>$openid,'headimgurl'=>urlencode($headimgurl),'nickname'=>$nickname,'tourl'=>urlencode($tourl)];
		$url = url('xcxdl',[],'',true);
		$url .= '?'.http_build_query($urlData);
		var_dump($url);
		exit;
		*/
		$tourl = urldecode($data['tourl']);
		if(!$tourl){
			$tourl = 'https://szx.yshdszx.com/xcxtg/index.html?id';
		}
		$wxInfo = ['unionid'=>$data['unionid'],'openid'=>$data['openid'],'headimgurl'=>urldecode($data['headimgurl']),'nickname'=>$data['nickname']];
		session(config('WX_KEY'),$wxInfo);
		header('location:'.$tourl);exit;
	}
	//微信分享成功
	public function fxcgnum(){
		$wxInfo = session(config('WX_KEY'));
		$table_name = $this->Data['table_name'];
		$id = $this->Data['id'];
		db($table_name)->where(['id'=>$id])->setInc('fx_nums',1);

			$data = array();
			$data['table_name'] = $table_name;
			$data['type_str'] = 'fx';
			$data['row_id'] = $id;		
			$data['create_time'] = time();
			$data['unionid'] = $wxInfo['unionid'];
			$data['openid'] = $wxInfo['openid'];
			$data['nickname'] = del_emoji($wxInfo['nickname']);
			$data['headimgurl'] = $wxInfo['headimgurl'];
			$data['wx_json'] = json_encode($wxInfo);
			db('articlesjl')->insert($data);

		return $this->successReturn('11');
	}
	
	//微信分享成功
	public function djkf(){
		$wxInfo = session(config('WX_KEY'));
		$table_name = 'kefu';
		$id = 100;

			$data = array();
			$data['table_name'] = $table_name;
			$data['type_str'] = 'djkf';
			$data['row_id'] = $id;		
			$data['create_time'] = time();
			$data['unionid'] = $wxInfo['unionid'];
			$data['openid'] = $wxInfo['openid'];
			$data['nickname'] = del_emoji($wxInfo['nickname']);
			$data['headimgurl'] = $wxInfo['headimgurl'];
			$data['wx_json'] = json_encode($wxInfo);
			db('articlesjl')->insert($data);

		return $this->successReturn('11');
	}
	//小程序分享
	public function fxcg(){
		$wxInfo = session(config('WX_KEY'));
		//$tourl = 'http://szx.yshdszx.com/xcxtg/hddetail.html?id=3';
		$data = gwhere();
		$tourl = urldecode($data['tourl']);
		if(!$tourl){
			exit;
		}
		$parse = parse_url($tourl);
		$path = $parse['path'];
		
		$arr = $this->convertUrlQuery($parse['query']);
		$id = 0;
		if($path=='/xcxtg/pyqdetail.html'){
			$table_name = 'pyq';
			$id = $arr['id'];
		}
		if($path=='/xcxtg/hddetail.html'){
			$table_name = 'huodong';
			$id = $arr['id'];
		}

		if($table_name && $id){
			db($table_name)->where(['id'=>$id])->setInc('fx_nums',1);
			$data = array();
			$data['table_name'] = $table_name;
			$data['type_str'] = 'fx';
			$data['row_id'] = $id;		
			$data['create_time'] = time();
			$data['unionid'] = $wxInfo['unionid'];
			$data['openid'] = $wxInfo['openid'];
			$data['nickname'] = del_emoji($wxInfo['nickname']);
			$data['headimgurl'] = $wxInfo['headimgurl'];
			$data['wx_json'] = json_encode($wxInfo);
			db('articlesjl')->insert($data);
			echo 'ok';
		}

		
		exit;
	}
	//小程序分享
	public function httprq(){
		//echo 'https://szx.yshdszx.com/api.php/index/httprq?tourl='.urlencode('https://api.weixin.qq.com/sns/jscode2session?appid=wxa2ae08d69daa71a1&secret=3b62c7ab9e85903f7520301df3bd97cf&js_code=033L9qXH1i5KW10KyVXH1f7DXH1L9qXM&grant_type=authorization_code');exit;
		//$tourl = 'http://szx.yshdszx.com/xcxtg/hddetail.html?id=3';
		$data = gwhere();
		$tourl = urldecode($data['tourl']);
		file_put_contents('ss.html',$to_url);
		file_put_contents('aa.html',json_encode($data));
		if(!$tourl){
			exit;
		}
		$contents = https_request($tourl);
		echo $contents;
	}
 /**
 * 解析url中参数信息，返回参数数组
 */
	public function convertUrlQuery($query){
		if(!$query){
			return [];
		}
	  $queryParts = explode('&', $query);
	  
	  $params = array();
	  foreach ($queryParts as $param) {
	   $item = explode('=', $param);
	   $params[$item[0]] = $item[1];
	  }
	  
	  return $params;
	}
	//消息列表
	public function huodong(){
		$wxInfo = session(config('WX_KEY'));

		$pagesize = $this->Data['page_size'];
		$page = $this->Data['page'];
		$page = $page>0 ? $page : 1;
		$pagesize = $pagesize>0 ? $pagesize : 20;
		
		$where = array('status'=>1);
		$title = $this->Data['title'];
		if($title){
			$where['title|sub_title'] = array('like',"%{$title}%");
		}

		$Model = db('huodong');
		$counts = $Model->where($where)->count();
		$start = ($page-1)*$pagesize;
		$limit = $start.','.$pagesize;

		
		$lists = $Model->where( $where )->order('o desc,id desc')->field('id,title,file_url,sub_title,create_time,zan_nums,sc_nums,pl_nums,view_nums,fx_nums')->limit($limit)->select();
		foreach($lists as $key=>$val){
			$lists[$key]['is_zan'] = $this->iscz('huodong','zan',$val['id'],$wxInfo);
			$lists[$key]['is_sc'] = $this->iscz('huodong','sc',$val['id'],$wxInfo);
		}
		return $this->successReturn('',$lists,$counts);
	}
	//消息详情
	public function huodonginfo(){
		$wxInfo = session(config('WX_KEY'));

		$id = $this->Data['id'];
		$Model = db('huodong');
		$info = $Model->where( array('status'=>1,'id'=>$id) )->find();
		if(!$info){
			return $this->errorReturn('未找到内容');
		}
		$info['app_contents'] = $this->baseHtml.$info['app_contents'];
		$info['is_zan'] = $this->iscz('huodong','zan',$info['id'],$wxInfo);
		$info['is_sc'] = $this->iscz('huodong','sc',$info['id'],$wxInfo);
		$Model->where(['id'=>$id])->setInc('view_nums',1);
		return $this->successReturn('',$info);
	}
	//评论列表
	public function articlespllists(){
		$wxInfo = session(config('WX_KEY'));

		$pagesize = $this->Data['page_size'];
		$page = $this->Data['page'];
		$page = $page>0 ? $page : 1;
		$pagesize = $pagesize>0 ? $pagesize : 20;
		
		
		$where = array('status'=>1);
		$table_name = $this->Data['table_name'];
		$pl_id = (int)$this->Data['pl_id'];
		$row_id = (int)$this->Data['id'];
		$where['row_id'] = $row_id;
		$where['table_name'] = $table_name;
		$where['pl_id'] = $pl_id;
		

		$Model = db('articlespl');
		$counts = $Model->where($where)->count();
		$start = ($page-1)*$pagesize;
		$limit = $start.','.$pagesize;

		
		$lists = $Model->where( $where )->order('o desc,id desc')->field('id,table_name,title,pl_id,openid,nickname,headimgurl,hf_nickname,hf_headimgurl,create_time,zan_nums,sc_nums,pl_nums,view_nums,fx_nums')->limit($limit)->select();
		foreach($lists as $key=>$val){
			$lists[$key]['is_zan'] = $this->iscz('articlespl','zan',$val['id'],$wxInfo);
			$lists[$key]['is_del'] = $wxInfo['openid']==$val['openid'] ? 1 : 0;
		}
		return $this->successReturn('',$lists,$counts);
	}
	//删除评论
	public function articlespldel(){
		$id = $this->Data['id'];
		$Model = db('articlespl');
		$Model->where(['id'=>$id])->delete();
		$Model->where(['pl_id'=>$id])->delete();
		return $this->successReturn('');
	}
	//评论数量计算
	public function plsljs($table_name,$row_id){		
		$counts = db('articlespl')->where(['table_name'=>$table_name,'row_id'=>$row_id,'pl_id'=>0])->count();
		db($table_name)->where(['id'=>$row_id])->update(['pl_nums'=>$counts]);
	}
	public function plsljspl($pl_id){		
		$counts = db('articlespl')->where(['pl_id'=>$pl_id])->count();
		db('articlespl')->where(['id'=>$pl_id])->update(['pl_nums'=>$counts]);
	}
	//问题表单
	public function wtbd(){
		$wxInfo = session(config('WX_KEY'));
		$ylsj = $this->Data['ylsj'];
		

		$Model = db('wtbd');
		$data = array(
					'ylsj_json'=>json_encode($ylsj,JSON_UNESCAPED_UNICODE),
					'create_time'=>time(),
				);
		
		$data['unionid'] = $wxInfo['unionid'];
		$data['openid'] = $wxInfo['openid'];
		$data['nickname'] = del_emoji($wxInfo['nickname']);
		$data['headimgurl'] = $wxInfo['headimgurl'];
		$data['wx_json'] = json_encode($wxInfo);

		$result = $Model->insertGetId($data);
		if(!$result){
			return $this->errorReturn('操作失败');
		}
		return $this->successReturn('操作成功');
	}
	//发布朋友圈
	public function fbpyq(){
		$wxInfo = session(config('WX_KEY'));
		if(!$wxInfo['openid']){
			return $this->errorReturn('请在微信中访问');
		}

		/*一分钟只允许发一次*/
		$lastTime = db('pyq')->where(['openid'=>$wxInfo['openid']])->order('id desc')->value('create_time');
		$timeLimit = time()-30;
		if($lastTime>$timeLimit){
			return $this->errorReturn('请勿频繁发帖');
		}

		$title = $this->Data['title'];
		$contents = $this->Data['contents'];
		$img_file_urls = $this->Data['img_file_urls'];
		$ylsj = $this->Data['ylsj'];
		//$img_file_urls = ['https://t.idianjiao.com/djedu/img/logo1.png','https://t.idianjiao.com/djedu/img/logo1.png'];
		if(!$title || !$contents){
			return $this->errorReturn('参数错误');
		}
		if(!is_array($img_file_urls) || !count($img_file_urls)){
			return $this->errorReturn('请上传一张图片');
		}
		
		$img_file_urls = array_unique($img_file_urls);

		$Model = db('pyq');
		$data = array(
					'title'=>$title,
					'sub_title'=>mb_substr($contents,0,30,'UTF-8'),
					'contents'=>$contents,
					'create_time'=>time(),
				);
		
		$data['unionid'] = $wxInfo['unionid'];
		$data['openid'] = $wxInfo['openid'];
		$data['nickname'] = del_emoji($wxInfo['nickname']);
		$data['headimgurl'] = $wxInfo['headimgurl'];
		$data['wx_json'] = json_encode($wxInfo);

		if(is_array($ylsj)){
			$data['ylsj_json'] = json_encode($ylsj);
		}

		

		$result = $Model->insertGetId($data);
		if(!$result){
			return $this->errorReturn('操作失败');
		}
		

		if(is_array($img_file_urls) && count($img_file_urls)){
			//$img_file_urls = array_reverse($img_file_urls);
			foreach($img_file_urls as $file_url){
				db('Tempfile')->where( array('file_url'=>$file_url) )->delete();
				$tempData = array('table_name'=>'pyq','pid'=>$result,'create_time'=>time(),'file_url'=>$file_url,'file_size'=>filesize($file_url));
				$tempData['resize_file_url'] = show_resize($file_url);
				db('filelists')->insert($tempData);
			}
		}

		return $this->successReturn('操作成功');
	
	}
	//朋友圈
	public function pyq(){
		$wxInfo = session(config('WX_KEY'));
		
		$pagesize = $this->Data['page_size'];
		$page = $this->Data['page'];
		$page = $page>0 ? $page : 1;
		$pagesize = $pagesize>0 ? $pagesize : 20;
		
		$where = array('status'=>1);
		$Model = db('pyq');
		$counts = $Model->where($where)->count();
		$start = ($page-1)*$pagesize;
		$limit = $start.','.$pagesize;
		
		$type = $this->Data['type'];
		if($type){
			$where['type_ids'] = array('like',"%,{$type},%");
		}else{
			$where['type_ids'] = array('like',"%,1,%");
		}

		$order = 'is_tj desc,id desc';
		$o = $this->Data['o'];
		//按时间，点赞数，阅读数，分享数降
		if($o=='time'){
			$order = 'id desc';
		}elseif($o=='zan'){
			$order = 'zan_nums desc';
		}elseif($o=='view'){
			$order = 'view_nums desc';
		}elseif($o=='pl'){
			$order = 'pl_nums desc';
		}elseif($o=='fx'){
			$order = 'fx_nums desc';
		}


		$lists = $Model->where( $where )->order($order)->field('id,title,sub_title,create_time,pl_nums,zan_nums,view_nums,fx_nums,openid,nickname,headimgurl')->limit($limit)->cache(true,2)->select();
		foreach($lists as $key=>$val){
			
			$pyqimg = $this->pyqimg($val['id']);
			$lists[$key] = array_merge($val,$pyqimg);			
			
			$lists[$key]['is_zan'] = $this->iscz('pyq','zan',$val['id'],$wxInfo);
			$lists[$key]['is_del'] = $wxInfo['openid']==$val['openid'] ? 1 : 0;
		}
		return $this->successReturn('',$lists,$counts);
	}
	//朋友圈图片列表
	public function pyqimg($pid,$table_name='pyq'){
		$Model = db('filelists');
		$file_lists = $Model->where(['table_name'=>$table_name,'pid'=>$pid,'status'=>1])->field('id,file_url,resize_file_url,ext,file_size')->order('id asc')->cache(false)->select();
		$img_file_urls = array();
		foreach($file_lists as $key=>$val){
			$id = $val['id'];
			$file_url = $val['file_url'];
			$img_file_urls[] = $file_url;
			if(!$val['ext']){
				$upData = array();
				$upData['ext'] = getExt($file_url);
				$upData['resize_file_url'] = show_resize($file_url);
				$Model->where(['id'=>$id])->update($upData);
			}
		}
		$return = array();
		$return['img_file_urls'] = $img_file_urls;
		$return['file_lists'] = $file_lists;
		$return['file_nums'] = count($file_lists);
		return $return;


	}
	//朋友圈详情
	public function pyqinfo(){
		$wxInfo = session(config('WX_KEY'));

		$id = $this->Data['id'];
		$info = db('pyq')->where(['id'=>$id])->cache(true,2)->find();
		if(!$info){
			return $this->errorReturn('该朋友圈已被删除');
		}
		$pyqimg = $this->pyqimg($id);
		$info = array_merge($info,$pyqimg);	
		$info['is_zan'] = $this->iscz('pyq','zan',$info['id'],$wxInfo);
		$info['is_del'] = $wxInfo['openid']==$info['openid'] ? 1 : 0;

		db('pyq')->where(['id'=>$id])->setInc('view_nums',1);
		return $this->successReturn('',$info);
	}
	//删除朋友圈
	public function pyqdel(){
		$id = $this->Data['id'];
		db('pyq')->where(['id'=>$id])->delete();
		return $this->successReturn('');
	}
	//评论
	public function articlespl(){
		$wxInfo = session(config('WX_KEY'));
		if(!$wxInfo['openid']){
			return $this->errorReturn('请在微信中访问');
		}
		
		$table_name = $this->Data['table_name'];
		$row_id = (int)$this->Data['id'];
		$pl_id = (int)$this->Data['pl_id'];
		$title = $this->Data['title'];
		if(!$table_name || !$row_id || !$title){
			return $this->errorReturn('参数错误');
		}
		$time = time();
		
		$Model = db('articlespl');
		//每小时评论数限制
		$time_limit = $time-60*60;
		$hf_nums = (int)db('sys')->where(['id'=>1])->value('hf_nums');
		$yft_nums = (int)$Model->where(['create_time'=>array('gt',$time_limit),'table_name'=>$table_name,'row_id'=>$row_id,'openid'=>$wxInfo['openid']])->count();
		if($yft_nums>=$hf_nums){
			return $this->errorReturn("请勿频繁评论！");
		}
		
		
		$data = array();
		$data['table_name'] = $table_name;
		$data['row_id'] = $row_id;
		$data['pl_id'] = $pl_id;
		$data['title'] = $title;
		$data['create_time'] = time();
		$data['unionid'] = $wxInfo['unionid'];
		$data['openid'] = $wxInfo['openid'];
		$data['nickname'] = del_emoji($wxInfo['nickname']);
		$data['headimgurl'] = $wxInfo['headimgurl'];
		$data['wx_json'] = json_encode($wxInfo);
		
		if($pl_id){
			//回复
			$info = $Model->where(['id'=>$pl_id])->find();
			$data['hf_unionid'] = $info['unionid'];
			$data['hf_openid'] = $info['openid'];
			$data['hf_nickname'] = $info['nickname'];
			$data['hf_headimgurl'] = $info['headimgurl'];
			$data['hf_wx_json'] = $info['wx_json'];
		}
		$Model->insert($data);
		
		if($pl_id){
			$this->plsljspl($pl_id);
		}else{
			$this->plsljs($table_name,$row_id);
		}
		return $this->successReturn('');

	}
	//文章、评论操作【点赞、收藏、报名】
	public function articlescz(){
		$wxInfo = session(config('WX_KEY'));
		if(!$wxInfo['openid']){
			return $this->errorReturn('请在微信中访问');
		}

		$table_name = $this->Data['table_name'];
		$type_str = $this->Data['type_str'];
		$row_id = $this->Data['id'];
		
		if(!$table_name || !$type_str || !$row_id){
			return $this->errorReturn('参数错误');
		}
		
		$is_cz = $this->iscz($table_name,$type_str,$row_id,$wxInfo);
		if($type_str=='zan' && $is_cz){
			db('articlesjl')->where(['table_name'=>$table_name,'type_str'=>$type_str,'row_id'=>$row_id,'openid'=>$wxInfo['openid']])->delete();
		}else{
			$data = array();
			$data['table_name'] = $table_name;
			$data['type_str'] = $type_str;
			$data['row_id'] = $row_id;		
			$data['create_time'] = time();
			$data['unionid'] = $wxInfo['unionid'];
			$data['openid'] = $wxInfo['openid'];
			$data['nickname'] = del_emoji($wxInfo['nickname']);
			$data['headimgurl'] = $wxInfo['headimgurl'];
			$data['wx_json'] = json_encode($wxInfo);
			db('articlesjl')->insert($data);
		}

		

		
		$this->cznum($data);
		return $this->successReturn('');
	}
	public function cznum($data){
		$type_str = $data['type_str'];
		$row_id = $data['row_id'];
		$table_name = $data['table_name'];
		$openid = $data['openid'];
		if(!in_array($type_str,['zan','sc'])){
			return false;
		}
		$where = array();
		$where['type_str'] = $type_str;
		$where['row_id'] = $row_id;
		$where['table_name'] = $table_name;
		$nums = db('articlesjl')->where($where)->count();
		
		$field = $type_str.'_nums';
		db($table_name)->where(['id'=>$row_id])->update([$field=>$nums]);
	}
	public function iscz($table_name,$type_str,$row_id,$wxInfo){
		$openid = $wxInfo['openid'];
		$where = array();
		$where['type_str'] = $type_str;
		$where['table_name'] = $table_name;
		$where['openid'] = $openid;
		$where['create_time'] = ['gt',strtotime(date('Y-m-d 00:00:00'))];
		$row_ids = db('articlesjl')->where($where)->column('row_id');
		$row_ids[] = 0;
		if(in_array($row_id,$row_ids)){
			return 1;
		}
		return 0;
	}
	//鱼类知识列表
	public function ylzs(){

		$pagesize = $this->Data['page_size'];
		$page = $this->Data['page'];
		$page = $page>0 ? $page : 1;
		$pagesize = $pagesize>0 ? $pagesize : 20;
		
		$where = array('status'=>1);
		$title = $this->Data['title'];
		if($title){
			$where['title|sub_title'] = array('like',"%{$title}%");
		}

		$Model = db('ylzs');
		$counts = $Model->where($where)->count();
		$start = ($page-1)*$pagesize;
		$limit = $start.','.$pagesize;

		
		$lists = $Model->where( $where )->order('o desc,id desc')->field('id,title,file_url,sub_title')->limit($limit)->select();
		return $this->successReturn('',$lists,$counts);
	}
	//鱼类知识详情
	public function ylzsinfo(){
		$id = $this->Data['id'];
		$Model = db('ylzs');
		$info = $Model->where( array('status'=>1,'id'=>$id) )->field('id,title,file_url,sub_title,app_contents')->find();
		if(!$info){
			return $this->errorReturn('未找到内容');
		}

		$info['app_contents'] = $this->baseHtml.$info['app_contents'];
		return $this->successReturn('',$info);
	}
	//备忘信息列表
	public function bwxx(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$pagesize = $this->Data['page_size'];
		$page = $this->Data['page'];
		$page = $page>0 ? $page : 1;
		$pagesize = $pagesize>0 ? $pagesize : 20;
		
		$where = array('status'=>1,'account_id'=>$userId);
		$Model = db('bwxx');
		$counts = $Model->where($where)->count();
		$start = ($page-1)*$pagesize;
		$limit = $start.','.$pagesize;

		$lists = $Model->where( $where )->order('id desc')->field('id,title,tx_time,create_time')->limit($limit)->select();
		return $this->successReturn('',$lists,$counts);
	}
	//提交备忘信息
	public function tjbwxx(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$title = $this->Data['title'];
		$contents = $this->Data['contents'];
		$tx_time = strtotime($this->Data['tx_time']);
		if(!$contents){
			return $this->errorReturn('请输入内容');
		}
		if(!$title){
			$title = mb_substr($contents,0,10,'UTF-8');
		}
		$data = array('account_id'=>$userId,'title'=>$title,'contents'=>$contents,'create_time'=>time());
		if($tx_time){
			$data['tx_time'] = $tx_time;
		}

		$Model = db('bwxx');
		$result = $Model->insert($data);

		return $this->successReturn('提交成功');
		
	}	
	//备忘信息详情
	public function bwxxinfo(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$id = $this->Data['id'];
		$Model = db('bwxx');
		$info = $Model->where( array('status'=>1,'id'=>$id,'account_id'=>$userId) )->field('id,title,contents,tx_time,create_time')->find();
		if(!$info){
			return $this->errorReturn('未找到内容');
		}
		
		return $this->successReturn('',$info);
	}
	//删除备忘信息
	public function bwxxdel(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$id = $this->Data['id'];
		$Model = db('bwxx');
		$result = $Model->where( array('id'=>$id,'account_id'=>$userId) )->delete();
		if(!$result){
			return $this->errorReturn('删除失败');
		}
		
		return $this->successReturn('删除成功');
	}
	//养鱼专家列表
	public function yyzj(){
		$pagesize = $this->Data['page_size'];
		$page = $this->Data['page'];
		$page = $page>0 ? $page : 1;
		$pagesize = $pagesize>0 ? $pagesize : 20;
		
		$where = array('status'=>1);
		$Model = db('yyzj');
		$counts = $Model->where($where)->count();
		$start = ($page-1)*$pagesize;
		$limit = $start.','.$pagesize;

		$lists = $Model->where( $where )->order('o desc,id desc')->field('id,title,file_url,sub_title,zhuanye,biaoqian,tags')->limit($limit)->select();
		return $this->successReturn('',$lists,$counts);
	}
	//养鱼专家详情
	public function yyzjinfo(){
		$id = $this->Data['id'];
		$Model = db('yyzj');
		$info = $Model->where( array('status'=>1,'id'=>$id) )->field('id,title,file_url,sub_title,app_contents,zhuanye,biaoqian,tags')->find();
		if(!$info){
			return $this->errorReturn('未找到内容');
		}

		$info['app_contents'] = $this->baseHtml.$info['app_contents'];
		return $this->successReturn('',$info);
	}
	//提交预约信息
	public function tjyyxx(){
		$userInfo = gU();
		$userId = $userInfo['id'];
		
		$yyzj_id = $this->Data['yyzj_id'];
		$link_man = $this->Data['link_man'] ? $this->Data['link_man'] : $userInfo['title'];
		$link_phone = $this->Data['link_phone'] ? $this->Data['link_phone'] : $userInfo['account'];
		$contents = $this->Data['contents'];
		$img_file_urls = $this->Data['img_file_urls'];
		$video_file_urls = $this->Data['video_file_urls'];
		if(!$contents || !$yyzj_id || !$link_man || !$link_phone){
			return $this->errorReturn('参数错误');
		}
		$zjInfo = db('yyzj')->where( array('id'=>$yyzj_id,'status'=>1) )->find();
		if(!$zjInfo){
			return $this->errorReturn('未找到专家');
		}
		
		$data = array();
		$data['account_id'] = $userId;
		$data['yyzj_id'] = $zjInfo['id'];
		$data['yyzj_title'] = $zjInfo['title'];
		$data['yyzj_file_url'] = $zjInfo['file_url'];
		$data['link_man'] = $link_man;
		$data['link_phone'] = $link_phone;
		$data['contents'] = $contents;
		$data['create_time'] = time();
		if(is_array($img_file_urls) && count($img_file_urls)){
			$tempArr = array();
			foreach($img_file_urls as $file_url){
				db('Tempfile')->where( array('file_url'=>$file_url) )->delete();
				if(file_exists($file_url)){
					$tempArr[] = $file_url;					
				}
			}
			$data['img_file_urls'] = json_encode($tempArr);
		}
		if(is_array($video_file_urls) && count($video_file_urls)){
			$tempArr = array();
			foreach($video_file_urls as $file_url){
				db('Tempfile')->where( array('file_url'=>$file_url) )->delete();
				if(file_exists($file_url)){
					$tempArr[] = $file_url;
				}
			}
			$data['video_file_urls'] = json_encode($tempArr);
		}
		
		$id = db('yyzjyy')->insertGetId($data);
		if(!$id){
			return $this->errorReturn('操作失败');
		}
		db('yyzjyy')->where( array('id'=>$id) )->update(['numbers'=>'SZ'.$id]);

		return $this->successReturn('预约成功');
	}
	//我的预约列表
	public function wdyylb(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$status = $this->Data['status'];
		$where = array('account_id'=>$userId);
		if($status){
			$where['status'] = $status;
		}

		$Model = db('yyzjyy');
		$lists = $Model->where( $where )->order('id desc')->select();
		foreach($lists as $key=>$val){
			$lists[$key]['img_file_urls'] = $val['img_file_urls'] ? json_decode($val['img_file_urls']) : array();
			$lists[$key]['video_file_urls'] = $val['video_file_urls'] ? json_decode($val['video_file_urls']) : array();
		}
		
		return $this->successReturn('',$lists);
	}
	//删除我的预约
	public function scwdyy(){
		$userInfo = gU();
		$userId = $userInfo['id'];
		
		$id = (int)$this->Data['id'];
		$Model = db('yyzjyy');
		$Model->where( array('id'=>$id,'account_id'=>$userId) )->delete();
		return $this->successReturn('操作成功');
	}
	//取消我的预约
	public function qxwdyy(){
		$userInfo = gU();
		$userId = $userInfo['id'];
		
		$id = (int)$this->Data['id'];
		$Model = db('yyzjyy');
		$Model->where( array('id'=>$id,'account_id'=>$userId,'status'=>1) )->update(['status'=>3]);
		return $this->successReturn('操作成功');
	}

	//添加鱼缸
	public function tjyg(){
		$userInfo = gU();
		$userId = $userInfo['id'];
		
		$title = $this->Data['title'];
		if(!$title){
			return $this->errorReturn('参数错误');
		}
		$Model = db('acccardtype');
		$data = array('account_id'=>$userId,'title'=>$title,'create_time'=>time());
		$result = $Model->insertGetId($data);
		if(!$result){
			return $this->errorReturn('创建失败');
		}
		$info = $Model->where( array('id'=>$result) )->find();
		return $this->successReturn('操作成功',$info);
	}
	//我的鱼缸列表
	public function yglists(){
		$userInfo = gU();
		$userId = $userInfo['id'];
		
		$Model = db('acccardtype');
		$lists = $Model->where( array('account_id'=>$userId,'status'=>1) )->order('o desc,id asc')->select();
		$Acccard = db('acccard');
		foreach($lists as $key=>$val){
			$lists[$key]['counts'] = $Acccard->where( array('acccardtype_id'=>$val['id']) )->count();
		}
		return $this->successReturn('',$lists);
	}
	//鱼缸详情
	public function yginfo(){
		$userInfo = gU();
		$userId = $userInfo['id'];
		
		$id = (int)$this->Data['id'];

		$Model = db('acccardtype');
		$info = $Model->where( array('account_id'=>$userId,'id'=>$id) )->find();
		if(!$info){
			return $this->errorReturn('未找到鱼缸');
		}
		
		return $this->successReturn('',$info);
	}
	//修改鱼缸
	public function xgyg(){
		$userInfo = gU();
		$userId = $userInfo['id'];
		
		$id = $this->Data['id'];
		$title = $this->Data['title'];
		if(!$title){
			return $this->errorReturn('参数错误');
		}
		$Model = db('acccardtype');
		$info = $Model->where( array('account_id'=>$userId,'id'=>$id) )->find();
		if(!$info){
			return $this->errorReturn('未找到鱼缸');
		}
		
		$data = array('title'=>$title,'update_time'=>time());
		$Model->where( array('id'=>$id) )->update($data);
		
		return $this->successReturn('操作成功');
	}
	//绑定设备
	public function bdsb(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$acccardtype_id = (int)$this->Data['acccardtype_id'];
		$card_id = $this->Data['card_id'];
		if(!$card_id){
			return $this->errorReturn('参数错误');
		}
		
		if($acccardtype_id){
			$tempInfo = db('acccardtype')->where( array('account_id'=>$userId,'id'=>$acccardtype_id) )->find();
			if(!$tempInfo){
				return $this->errorReturn('未找到分组');
			}
		}

		//设备是否激活
		$Cardid = db('cardid');
		$info = $Cardid->where( array('card_id'=>$card_id) )->find();
		if(!$info){
			return $this->errorReturn('设备尚未激活');
		}

		$cardid_id = $info['id'];	
		$card_type = $info['card_type'];

		$fieldData = config('FIELD_DATA');
		$fieldData = $fieldData['card_type'];
		$dataList = $fieldData['dataList'];

		$title = $dataList[$card_type]['title'];
		$data = array();
		$data['account_id'] = $userId;	
		$data['acccardtype_id'] = $acccardtype_id;		
		$data['cardid_id'] = $cardid_id;
		$data['card_type'] = $card_type;
		$data['card_id'] = $card_id;
		$data['title'] = $title;
		$data['create_time'] = time();
		
		$Model = db('acccard');
		$have = $Model->where( array('account_id'=>$userId,'card_id'=>$card_id) )->find();
		if($have){
			return $this->successReturn('操作成功');
		}

		$result = $Model->insertGetId($data);
		if(!$result){
			return $this->errorReturn('绑定失败');
		}
		return $this->successReturn('操作成功');
	}
	//获取鱼缸下的设备
	public function ygsb(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$acccardtype_id = (int)$this->Data['acccardtype_id'];
		$lists = db('acccard')->where( array('account_id'=>$userId,'acccardtype_id'=>$acccardtype_id,'status'=>1) )->select();
		foreach($lists as $key=>$val){
			$lists[$key]['is_online'] = isonline($val['card_id']);
		}

		return $this->successReturn('操作成功',$lists);
	}
	//移动设备到鱼缸
	public function tjsbdyg(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$acccardtype_id = (int)$this->Data['acccardtype_id'];
		$ids = $this->Data['ids'];
		$ids[] = 0;
		//$ids = array('1');

		if(!is_array($ids) || !count($ids)){
			//return $this->errorReturn('参数错误');
		}

		if($acccardtype_id){
			$tempInfo = db('acccardtype')->where( array('account_id'=>$userId,'id'=>$acccardtype_id) )->find();
			if(!$tempInfo){
				return $this->errorReturn('未找到分组');
			}
		}

		//修改未勾选的设备到常用设备
		db('acccard')->where( array('account_id'=>$userId,'id'=>array('notin',$ids),'acccardtype_id'=>$acccardtype_id) )->update(['acccardtype_id'=>0,'update_time'=>time()]);
		
		$data = array('acccardtype_id'=>$acccardtype_id,'update_time'=>time());
		$result = db('acccard')->where( array('account_id'=>$userId,'id'=>array('in',$ids)) )->update($data);
		if($result===false){
			return $this->errorReturn('操作失败');
		}
		return $this->successReturn('操作成功');
	}
	//删除设备
	public function scsb(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$id = (int)$this->Data['id'];
		$result = db('acccard')->where( array('account_id'=>$userId,'id'=>$id) )->delete();

		return $this->successReturn('操作成功');
	}
	//删除鱼缸
	public function scyg(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$id = (int)$this->Data['id'];
		$result = db('acccardtype')->where( array('account_id'=>$userId,'id'=>$id) )->delete();
		if(!$result){
			return $this->errorReturn('操作失败');
		}

		//设备移动到常用设备
		$data = array('acccardtype_id'=>0,'update_time'=>time());
		db('acccard')->where( array('account_id'=>$userId,'acccardtype_id'=>$id) )->update($data);

		return $this->successReturn('操作成功');
	}
	//水质监测实时数据
	public function szjcsssj(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$id = $this->Data['id'];
		$info = db('acccard')->where( array('id'=>$id,'account_id'=>$userId) )->cache(true)->find();
		if(!$info){
			return $this->errorReturn('未找到设备');
		}
		$card_id = $info['card_id'];

		$is_online = isonline($card_id);
		$return = array();
		$return['is_online'] = $is_online;
		$return['wd'] = 0;
		$return['ph'] = 0;
		$return['tds'] = 0;
		$return['wd_zl'] = 0;
		$return['ph_zl'] = 0;
		$return['tds_zl'] = 0;
		$return['zl'] = 0;
		if($is_online){
			$ym = date('ym');
			//温度
			$wdInfo = db('datawd'.$ym)->where( array('card_id'=>$card_id) )->order('id desc')->field('id,true_value,create_time')->find();
			//PH
			$phInfo = db('dataph'.$ym)->where( array('card_id'=>$card_id) )->order('id desc')->field('id,true_value,create_time')->find();
			//TDS
			$tdsInfo = db('datatds'.$ym)->where( array('card_id'=>$card_id) )->order('id desc')->field('id,true_value,create_time')->find();

			$return['wd'] = $wdInfo['true_value'] ? $wdInfo['true_value'] : 0;
			$return['ph'] = $phInfo['true_value'] ? $phInfo['true_value'] : 0;
			$tds = $tdsInfo['true_value'] ? $tdsInfo['true_value'] : 0;
			$return['tds'] = $tds;
			$zl = 0;
			if($tds>=0 && $tds<=100){
				$zl = 1;
			}elseif($tds>100 && $tds<=200){
				$zl = 2;
			}elseif($tds>200 && $tds<=300){
				$zl = 3;
			}elseif($tds>300 && $tds<=500){
				$zl = 4;
			}elseif($tds>500){
				$zl = 5;
			}
			$return['zl'] = $zl;

			if($return['wd']<26){
				$return['wd_zl'] = 1;
			}elseif($return['wd']>31.5){
				$return['wd_zl'] = 2;
			}
			
			if($return['tds']>500){
				$return['tds_zl'] = 2;
			}
			
			if($return['ph']<6){
				$return['ph_zl'] = 1;
			}elseif($return['ph']>8.6){
				$return['ph_zl'] = 2;
			}
		}
		return $this->successReturn('',$return);
	}

	//水质监测统计图数据
	public function szjctjtsj(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$id = $this->Data['id'];
		$data_type = $this->Data['data_type'];//wd,ph,tds
		$days = $this->Data['days'] ? $this->Data['days'] : date('Ymd');//20180805
		$time_limit = $this->Data['time_limit'];//10
		$time_limit = $time_limit ? $time_limit : 10;

		$ymd = date('ymd',strtotime($days));
		$ym = date('ym',strtotime($days));
		$start_time = strtotime($days.' 00:00:00');

		

		if(!$id || !$data_type || !$days){
			return $this->errorReturn('参数错误');
		}
		
		$Model = false;
		switch($data_type){
			case 'wd':
					$Model = db('datawd'.$ym);
				break;
			case 'ph':
					$Model = db('dataph'.$ym);
				break;
			case 'tds':
					$Model = db('datatds'.$ym);
				break;
		}
		if(!$Model){
			return $this->errorReturn('参数错误');
		}

		$info = db('acccard')->where( array('id'=>$id,'account_id'=>$userId) )->cache(true)->find();
		if(!$info){
			return $this->errorReturn('未找到设备');
		}
		$card_id = $info['card_id'];

		
		$where = array('card_id'=>$card_id,'ymd'=>$ymd );
		if($ym<1808){
			$lists = array();
		}else{
			$lists = $Model->where( $where )->order('id asc')->field('ymdhi,true_value,create_time')->select();
		}
		
		
		$dbArr = array();
		$end_time = $start_time+24*60*60;
		$this_time = $start_time;
		$one_limit = $time_limit*60;
		while($this_time<$end_time){			
			$this_time = $this_time+$one_limit;			
			$dbArr[$this_time] = 0;
		}

		foreach($lists as $key=>$val){
			$create_time = $val['create_time'];
			$create_time = $create_time-$create_time%$one_limit;
			if(isset($dbArr[$create_time])){
				$dbArr[$create_time] = $val['true_value'];
			}			
		}


		$return = array();
		foreach($dbArr as $x=>$y){
			$return[] = array('x'=>$x,'y'=>$y);
		}

		return $this->successReturn('',$return);
		

	}
	//温度报警详情
	public function bjwdinfo(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$id = $this->Data['id'];
		$info = db('acccard')->where( array('id'=>$id,'account_id'=>$userId) )->cache(true)->find();
		if(!$info){
			return $this->errorReturn('未找到设备');
		}
		$cardInfo = db('cardid')->where( array('card_id'=>$info['card_id']) )->find();

		if(!$cardInfo['value_json']){
			$arr = array(22.5,26.0,31.5,33.5);
		}else{
			$arr = json_decode($cardInfo['value_json'],true);
		}

		$return = array('sz_status'=>$cardInfo['wd_status'],'sz_time'=>$cardInfo['wd_time']);
		$return['v_1'] = $arr[0];
		$return['v_2'] = $arr[1];
		$return['v_3'] = $arr[2];
		$return['v_4'] = $arr[3];
		return $this->successReturn('',$return);
	}
	//设置报警温度
	public function szbjwd(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$id = $this->Data['id'];
		$v_1 = $this->Data['v_1'];
		$v_2 = $this->Data['v_2'];
		$v_3 = $this->Data['v_3'];
		$v_4 = $this->Data['v_4'];
		if(!$v_1 || !$v_2 || !$v_3 || !$v_4){
			return $this->errorReturn('参数错误');
		}

		$value_arr = array($v_1,$v_2,$v_3,$v_4);
		//$value_arr = array(24.5,27,28,29.5);
		
		foreach($value_arr as $key=>$val){
			$value_arr[$key] = sprintf("%.1f", $val);
		}

		$info = db('acccard')->where( array('id'=>$id,'account_id'=>$userId) )->cache(false)->find();
		if(!$info){
			return $this->errorReturn('未找到设备');
		}
		$card_id = $info['card_id'];
		
		//设备是否在线
		if(!isonline($card_id)){
			return $this->errorReturn('设备离线');
		}
		

		$data_type = 37;
		$card_type = $info['card_type'];
		$baseArr = config('baseArr');
		$title = $baseArr[$card_type][$data_type]['title'];
		$data = array();
		$data['account_id'] = $userId;
		$data['acccard_id'] = $id;
		$data['acccardtype_id'] = $info['acccardtype_id'];
		$data['card_type'] = $info['card_type'];
		$data['card_id'] = $card_id;
		$data['data_type'] = $data_type;
		$data['title'] = $title;
		$data['value_json'] = json_encode($value_arr);
		$data['create_time'] = time();

		db('datasend')->where( array('card_id'=>$card_id,'data_type'=>$data_type,'status'=>1) )->setField('status',4);
		$result = db('datasend')->insertGetId($data);
		

		if(!$result){
			return $this->errorReturn('操作失败');
		}
		db('cardid')->where( array('card_id'=>$card_id) )->update(['wd_status'=>1,'wd_time'=>time()]);

		return $this->successReturn('操作成功');
	}
	//PH报警详情
	public function phinfo(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$id = $this->Data['id'];
		$info = db('acccard')->where( array('id'=>$id,'account_id'=>$userId) )->cache(true)->find();
		if(!$info){
			return $this->errorReturn('未找到设备');
		}
		$cardInfo = db('cardid')->where( array('card_id'=>$info['card_id']) )->find();

		if(!$cardInfo['value_json_ph']){
			$arr = array(6.0,8.6);
		}else{
			$arr = json_decode($cardInfo['value_json_ph'],true);
		}

		$return = array('sz_status'=>$cardInfo['ph_status'],'sz_time'=>$cardInfo['ph_time']);		
		$return['v_1'] = $arr[0];	
		$return['v_2'] = $arr[1];
		return $this->successReturn('',$return);
	}
	//设置报警PH值
	public function szbjph(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$id = $this->Data['id'];
		$v_1 = $this->Data['v_1'];
		$v_2 = $this->Data['v_2'];
		
		if(!$v_1 || !$v_2){
			return $this->errorReturn('参数错误');
		}

		$value_arr = array($v_1,$v_2);
		foreach($value_arr as $key=>$val){
			$value_arr[$key] = sprintf("%.2f", $val);
		}

		$info = db('acccard')->where( array('id'=>$id,'account_id'=>$userId) )->cache(true)->find();
		if(!$info){
			return $this->errorReturn('未找到设备');
		}
		$card_id = $info['card_id'];
		
		//设备是否在线
		if(!isonline($card_id)){
			return $this->errorReturn('设备离线');
		}
		

		$data_type = 38;
		$card_type = $info['card_type'];
		$baseArr = config('baseArr');
		$title = $baseArr[$card_type][$data_type]['title'];
		$data = array();
		$data['account_id'] = $userId;
		$data['acccard_id'] = $id;
		$data['acccardtype_id'] = $info['acccardtype_id'];
		$data['card_type'] = $info['card_type'];
		$data['card_id'] = $card_id;
		$data['data_type'] = $data_type;
		$data['title'] = $title;
		$data['value_json'] = json_encode($value_arr);
		$data['create_time'] = time();

		db('datasend')->where( array('card_id'=>$card_id,'data_type'=>$data_type,'status'=>1) )->setField('status',4);
		$result = db('datasend')->insertGetId($data);
		

		if(!$result){
			return $this->errorReturn('操作失败');
		}
		db('cardid')->where( array('card_id'=>$card_id) )->update(['ph_status'=>1,'ph_time'=>time()]);

		return $this->successReturn('操作成功');
	}
	//发送ph校准
	public function phjz(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$id = $this->Data['id'];
		//$num = (int)$this->Data['num'];
		$v_1 = $this->Data['v_1'];
		$v_2 = $this->Data['v_2'];
		if(!$v_1 || !$v_2){
			return $this->errorReturn('参数错误');
		}
		if(($v_1<2 || $v_1>12) || ($v_2<2 || $v_2>12) ){
			return $this->errorReturn('PH值范围：2~12');
		}

		$v_1 = sprintf("%.2f", $v_1);
		$v_2 = sprintf("%.2f", $v_2);

		$info = db('acccard')->where( array('id'=>$id,'account_id'=>$userId) )->cache(true)->find();
		if(!$info){
			return $this->errorReturn('未找到设备');
		}
		$card_id = $info['card_id'];

		
		//设备是否在线
		if(!isonline($card_id)){
			return $this->errorReturn('设备离线');
		}

		$cardInfo = db('cardid')->where( array('card_id'=>$info['card_id']) )->field('phjz_status,phjz_time')->find();
		$phjz_status = $cardInfo['phjz_status'];
		//设置设备校准状态 PH校准状态 ’0’：校准失败，’1’：第一次校准成功，’2’：校准成功,’3’:第一次PH校准APP触发成功，’4’:第二次PH校准APP触发成功,’5’:正在进行按键校准,’6’:正在进行APP第一次PH校准,’7’:正在等待APP输入第二次校准值，’8’:正在进行APP第二次PH校准
		if(!in_array($phjz_status,[-1,0,2])){
			return $this->errorReturn('正在校准中');
		}
		
		$time = time();
		$data_type = 43;
		//第一次发送值
		$card_type = $info['card_type'];
		$baseArr = config('baseArr');
		$title = $baseArr[$card_type][$data_type]['title'];
		$data = array();
		$data['account_id'] = $userId;
		$data['acccard_id'] = $id;
		$data['acccardtype_id'] = $info['acccardtype_id'];
		$data['card_type'] = $info['card_type'];
		$data['card_id'] = $card_id;
		$data['data_type'] = $data_type;
		$data['title'] = $title;
		$data['value_json'] = json_encode(array($v_1));
		$data['create_time'] = $time;

		db('datasend')->where( array('card_id'=>$card_id,'data_type'=>$data_type,'status'=>1) )->setField('status',4);
		$result = db('datasend')->insertGetId($data);
		

		if(!$result){
			return $this->errorReturn('操作失败');
		}

		db('cardid')->where( array('card_id'=>$card_id) )->update(['phjz_status'=>3,'phjz_v_1'=>$v_1,'phjz_v_2'=>$v_2,'phjz_time'=>$time]);
		
		return $this->successReturn('操作成功');

	}
	//当前PH校准状态
	public function phjzinfo(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$id = $this->Data['id'];
		$info = db('acccard')->where( array('id'=>$id,'account_id'=>$userId) )->cache(true)->find();
		if(!$info){
			return $this->errorReturn('未找到设备');
		}
		$cardInfo = db('cardid')->where( array('card_id'=>$info['card_id']) )->field('phjz_status,phjz_time')->find();
		
		//PH校准状态 ’0’：校准失败，’1’：第一次校准成功，’2’：校准成功,’3’:第一次PH校准APP触发成功，’4’:第二次PH校准APP触发成功,’5’:正在进行按键校准,’6’:正在进行APP第一次PH校准,’7’:正在等待APP输入第二次校准值，’8’:正在进行APP第二次PH校准
		$phjz_status = $cardInfo['phjz_status'];
		$sz_status= 0;//sz_status:设置状态（0:未设置，1：正在设置，2：设置成功，3：设置失败）
		if(in_array($phjz_status,[1,3,4,5,6,7,8])){
			$sz_status = 1;
		}elseif(in_array($phjz_status,[2])){
			$sz_status = 2;
		}elseif(in_array($phjz_status,[0])){
			$sz_status = 3;
		}
		
		$return = array('sz_status'=>$sz_status,'sz_time'=>$cardInfo['phjz_time']);		
		return $this->successReturn('',$return);

	}
	//TDS报警详情
	public function tdsinfo(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$id = $this->Data['id'];
		$info = db('acccard')->where( array('id'=>$id,'account_id'=>$userId) )->cache(true)->find();
		if(!$info){
			return $this->errorReturn('未找到设备');
		}
		$cardInfo = db('cardid')->where( array('card_id'=>$info['card_id']) )->find();

		if(!$cardInfo['value_json_tds']){
			$arr = array(500);
		}else{
			$arr = json_decode($cardInfo['value_json_tds'],true);
		}

		$return = array('sz_status'=>$cardInfo['tds_status'],'sz_time'=>$cardInfo['tds_time']);
		$return['v_1'] = $arr[0];
		return $this->successReturn('',$return);
	}
	//设置报警tds值
	public function szbjtds(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$id = $this->Data['id'];
		$v_1 = (int)$this->Data['v_1'];
		
		if(!$v_1){
			return $this->errorReturn('参数错误');
		}
		if($v_1<500 || $v_1>1500){
			return $this->errorReturn('报警值在500~1500之间');	
		}

		$value_arr = array($v_1);
		foreach($value_arr as $key=>$val){
			$value_arr[$key] = (int)$val;	
		}
		$info = db('acccard')->where( array('id'=>$id,'account_id'=>$userId) )->cache(true)->find();
		if(!$info){
			return $this->errorReturn('未找到设备');
		}
		$card_id = $info['card_id'];
		
		//设备是否在线
		if(!isonline($card_id)){
			return $this->errorReturn('设备离线');
		}
		

		$data_type = 39;
		$card_type = $info['card_type'];
		$baseArr = config('baseArr');
		$title = $baseArr[$card_type][$data_type]['title'];
		$data = array();
		$data['account_id'] = $userId;
		$data['acccard_id'] = $id;
		$data['card_type'] = $info['card_type'];
		$data['card_id'] = $card_id;
		$data['data_type'] = $data_type;
		$data['title'] = $title;
		$data['value_json'] = json_encode($value_arr);
		$data['create_time'] = time();

		db('datasend')->where( array('card_id'=>$card_id,'data_type'=>$data_type,'status'=>1) )->setField('status',4);
		$result = db('datasend')->insertGetId($data);
		

		if(!$result){
			return $this->errorReturn('操作失败');
		}
		db('cardid')->where( array('card_id'=>$card_id) )->update(['tds_status'=>1,'tds_time'=>time()]);

		return $this->successReturn('操作成功');
	}

	
	
	//报警开关详情
	public function kginfo(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$id = $this->Data['id'];
		$info = db('acccard')->where( array('id'=>$id,'account_id'=>$userId) )->cache(true)->find();
		if(!$info){
			return $this->errorReturn('未找到设备');
		}
		$cardInfo = db('cardid')->where( array('card_id'=>$info['card_id']) )->find();

		if(!$cardInfo['value_json_kg']){
			$arr = array(1);
		}else{
			$arr = json_decode($cardInfo['value_json_kg'],true);
		}

		$return = array('sz_status'=>$cardInfo['kg_status'],'sz_time'=>$cardInfo['kg_time']);
		$return['v_1'] = $arr[0];
		return $this->successReturn('',$return);
	}
	//设置报警开关
	public function szbjkg(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$id = $this->Data['id'];
		$v_1 = (int)$this->Data['v_1'];
		$v_1 = $v_1 ? 1 : 0;
		$value_arr = array($v_1);
		
		$info = db('acccard')->where( array('id'=>$id,'account_id'=>$userId) )->cache(true)->find();
		if(!$info){
			return $this->errorReturn('未找到设备');
		}
		$card_id = $info['card_id'];
		
		//设备是否在线
		if(!isonline($card_id)){
			return $this->errorReturn('设备离线');
		}		

		$data_type = '4c';
		$card_type = $info['card_type'];
		$baseArr = config('baseArr');
		$title = $baseArr[$card_type][$data_type]['title'];
		$data = array();
		$data['account_id'] = $userId;
		$data['acccard_id'] = $id;
		$data['card_type'] = $info['card_type'];
		$data['card_id'] = $card_id;
		$data['data_type'] = $data_type;
		$data['title'] = $title;
		$data['value_json'] = json_encode($value_arr);
		$data['create_time'] = time();

		db('datasend')->where( array('card_id'=>$card_id,'data_type'=>$data_type,'status'=>1) )->setField('status',4);
		$result = db('datasend')->insertGetId($data);
		

		if(!$result){
			return $this->errorReturn('操作失败');
		}
		db('cardid')->where( array('card_id'=>$card_id) )->update(['kg_status'=>1,'kg_time'=>time()]);

		return $this->successReturn('操作成功');
	}
	
	//设备日志
	public function bjlog(){
		$userInfo = gU();
		$userId = $userInfo['id'];
		/*
		$card_ids = db('acccard')->where( array('account_id'=>$userId) )->column('card_id');
		if(!is_array($card_ids) || !count($card_ids)){
			return $this->successReturn('获取成功',[],0);
		}
		*/

		$pagesize = $this->Data['page_size'];
		$page = $this->Data['page'];
		$page = $page>0 ? $page : 1;
		$pagesize = $pagesize>0 ? $pagesize : 20;
		
		$where = array('account_id'=>$userId);
		$type_id = (int)$this->Data['type_id']; //1:报警，2：操作
		if($type_id){
			$where['type_id'] = $type_id;
		}

		$start_date = $this->Data['start_date'];
		$end_date = $this->Data['end_date'];
		if($start_date && $end_date){
			$start_time = strtotime($start_date.' 00:00:00');
			$end_time = strtotime($end_date.' 23:59:59');
			$where['create_time'] = array('between',array($start_time,$end_time));
		}

		$Model = db('databjlog');
		$counts = $Model->where($where)->count();
		$start = ($page-1)*$pagesize;
		$limit = $start.','.$pagesize;
		$lists = $Model->where($where)->field('id,card_type,data_type,true_value,acccardtype_title,create_time,value_json,is_read')->order('id desc')->limit($limit)->select();
		
		foreach($lists as $key=>$val){
			$card_type = $val['card_type'];
			$data_type = $val['data_type'];
			$true_value = $val['true_value'];
			$acccardtype_title = $val['acccardtype_title'];
			$value_json = $val['value_json'];
			$lists[$key]['title'] = bjtitle($card_type,$data_type,$true_value,$acccardtype_title,$value_json);
		}

		return $this->successReturn('获取成功',$lists,$counts);
	}
	//设置报警已读
	public function readbj(){
		$id = $this->Data['id'];
		$Model = db('databjlog');
		$Model->where(['id'=>$id])->update(['is_read'=>1]);
		return $this->successReturn('');
	}
	//最新设备日志
	public function newlog(){
		$userInfo = gU();
		$userId = $userInfo['id'];
		
		/*
		$card_ids = db('acccard')->where( array('account_id'=>$userId) )->column('card_id');
		if(!is_array($card_ids) || !count($card_ids)){
			return $this->successReturn('获取成功',[]);
		}
		*/
		$times = $this->Data['times'];		
		if($times){
			$time_limit = $times;
		}else{
			$time_limit = time()-20*60;
		}
		$where = array('account_id'=>$userId,'type_id'=>1,'create_time'=>array('gt',$time_limit));
		$Model = db('databjlog');
		$lists = $Model->where($where)->field('id,card_type,data_type,true_value,acccardtype_title,create_time,value_json,is_read')->order('id desc')->limit('0,5')->select();
		
		foreach($lists as $key=>$val){
			$card_type = $val['card_type'];
			$data_type = $val['data_type'];
			$true_value = $val['true_value'];
			$acccardtype_title = $val['acccardtype_title'];
			$value_json = $val['value_json'];
			$lists[$key]['title'] = bjtitle($card_type,$data_type,$true_value,$acccardtype_title,$value_json);
		}

		return $this->successReturn('获取成功',$lists,$counts);
	}
	//智能统计
	public function zntj(){
		$userInfo = gU();
		$userId = $userInfo['id'];
		
		$return = array();
		//鱼缸
		$return['ygsl'] = db('acccardtype')->where(['account_id'=>$userId])->count();
		//设备数量
		$sbsl = 0;
		$ycsb = 0;
		$sbArr = db('acccard')->where(['account_id'=>$userId])->column('card_id');
		
		if(is_array($sbArr) && count($sbArr)){
			$sbsl = count($sbArr);
			$ycsb = db('cardid')->where( ['card_id'=>array('in',$sbArr),'update_time'=>array('lt',time()-120)] )->count();			
		}

		$return['sbsl'] = $sbsl;
		$return['ycsb'] = $ycsb;
		$card_type_arr = getFieldData('card_type');
		$sbfb = array();
		foreach($card_type_arr as $key=>$val){
			$card_type = $val['value'];
			$temp = array('card_type'=>$card_type,'title'=>$val['title']);
			$temp['nums'] = db('acccard')->where(['account_id'=>$userId,'card_type'=>$card_type])->count();
			
			$sbfb[] = $temp;
		}
		$return['sbfb'] = $sbfb;

		//操作、报警
		$czsl = db('databjlog')->where(['account_id'=>$userId,'type_id'=>2])->count();
		$bjsl = db('databjlog')->where(['account_id'=>$userId,'type_id'=>1])->count();
		$return['czsl'] = $czsl;
		$return['bjsl'] = $bjsl;

		return $this->successReturn('获取成功',$return);
	}
	


	//登录
	public function login(){
		$account = trim($this->Data['account']);
		$password = encrypt_my($this->Data['password']);
		$jpush_id = $this->Data['jpush_id'];

		if(!$account || !$password){
			return $this->errorReturn('参数错误');
		}
		$Model = db('account');
		$info = $Model->where( array('account'=>$account,'password'=>$password) )->find();
		if(!$info){
			return $this->errorReturn('账号或密码错误');
		}
		
		$time = time();
		$login_verf = encrypt_my($time.rand(1000,9999));
		$data = ['login_verf'=>$login_verf,'login_time'=>$time];
		if($jpush_id){
			//清空别的账号 jpush_id
			$Model->where( array('jpush_id'=>$jpush_id) )->setField('jpush_id','');
			$data['jpush_id'] = $jpush_id;
		}
		$Model->where( ['id'=>$info['id']] )->update($data);
		session(config('ACCOUNT_KEY'),$info['id']);
		return $this->successReturn('登录成功',['login_verf'=>$login_verf]);
	}
	//登录密码登录(自动登录)
	public function verflogin(){
		$login_verf = trim($this->Data['login_verf']);
		$Model = db('account');
		$info = $Model->where( array('login_verf'=>$login_verf) )->find();
		if(!$info){
			return $this->errorReturn('验证码错误');
		}
		
		$time = time();
		$login_verf = encrypt_my($time.rand(1000,9999));
		$Model->where( ['id'=>$info['id']] )->update(['login_verf'=>$login_verf,'login_time'=>$time]);
		session(config('ACCOUNT_KEY'),$info['id']);
		return $this->successReturn('登录成功',['login_verf'=>$login_verf]);
	}	
	//修改密码
	public function resetpass(){
		$account = trim($this->Data['account']);
		$verf = $this->Data['verf'];
		$password = encrypt_my($this->Data['password']);
		
		if(!$account || !$verf || !$password){
			return $this->errorReturn('参数错误');
		}

		if(!checkVerf($account,$verf)){
			return $this->errorReturn('短信验证码错误');
		}

		$Model = db('account');
		$info = $Model->where( array('account'=>$account) )->find();
		if(!$info){
			return $this->errorReturn('未找到账号');
		}
		$time = time();
		$result = $Model->where( ['id'=>$info['id']] )->update(['password'=>$password,'update_time'=>$time]);
		if(!$result){
			return $this->errorReturn('操作失败');
		}
		return $this->successReturn('操作成功');
	}
	//用户详情
	public function userinfo(){
		$userInfo = gU();
		$userId = $userInfo['id'];
		if($userInfo['file_url']){			
			$userInfo['file_url'] = show_resize($userInfo['file_url']);
		}else{
			$userInfo['file_url'] = 'static/header.jpg';
		}
		
		return $this->successReturn('',$userInfo);
		
	}
	//设置用户详情
	public function setinfo(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$title = $this->Data['title'];
		$file_url = $this->Data['file_url'];
		$ts_status = $this->Data['ts_status'] ? 1 : 0;
		if(!$title){
			return $this->errorReturn('参数错误');
		}
		$data = array('title'=>$title,'ts_status'=>$ts_status,'update_time'=>time());
		if($file_url){
			$data['file_url'] = $file_url;
			db('Tempfile')->where( array('file_url'=>$file_url) )->delete();
		}
		db('account')->where( array('id'=>$userId) )->update($data);
		sU();
		return $this->successReturn('操作成功');
	}
	//注册
	public function reg(){
		$account = trim($this->Data['account']);
		$verf = $this->Data['verf'];
		$password = encrypt_my($this->Data['password']);
		$title = $this->Data['title'];
		if(!$account || !$verf || !$password){
			return $this->errorReturn('参数错误');
		}
		
		if(!checkVerf($account,$verf)){
			return $this->errorReturn('短信验证码错误');
		}
		$Model = db('account');
		$have = $Model->where( array('account'=>$account) )->find();
		if($have){
			return $this->errorReturn('手机号已存在');
		}

		$time = time();
		$data = array();
		$data['account'] = $account;
		$data['password'] = $password;
		$data['title'] = $title;
		$data['create_time'] = $time;
		$result = $Model->insertGetId($data);
		if(!$result){
			return $this->errorReturn('注册失败');
		}

		
		$login_verf = encrypt_my($time.rand(1000,9999));
		$Model->where( ['id'=>$result] )->update(['login_verf'=>$login_verf,'login_time'=>$time]);

		session(config('ACCOUNT_KEY'),$result);
		return $this->successReturn('注册成功',['login_verf'=>$login_verf]);
	}
	//系统信息
	public function sysinfo(){
		$info = db('sys')->where( array('id'=>config('SYS_ID')) )->field('title,link_man,telphone,address,company_right,zc_contents')->cache(true)->find();
		return $this->successReturn('获取成功',$info);
	}
	//公司介绍
	public function companyinfo(){
		$info = db('sys')->where( array('id'=>config('SYS_ID')) )->field('app_contents')->cache(true)->find();
		$info['app_contents'] = hscd($info['app_contents']);
		return $this->successReturn('获取成功',$info);
	}
	
	//系统版本
	public function cv(){
		$app = $this->Data['app'];
		
		$info = db('apkv')->where( array('type'=>$app) )->order('v_num desc')->field('v_title,v_num,http_url')->find();
		if(!$info){
			return $this->errorReturn('无版本');
		}
		if(substr($info['http_url'],0,4)!='http'){
			$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
			$info['http_url'] = "$protocol{$_SERVER['HTTP_HOST']}/".$info['http_url'];
		}
		return $this->successReturn('',$info);
	}
	//发送短信验证码
	public function sendverf(){

		$phone = $this->Data['phone'];
		if(!$phone){
			return $this->errorReturn('参数错误');
		}
		$tempId = 'SMS_141925255';

		$result = sendVerf($phone,$tempId,'壹生互动');
		if(!$result){
			return $this->errorReturn('短信发送失败！');
		}
		session('send_time',time());
		return $this->successReturn('短信发送成功！');
	}
	//上传文件
	public function upfile(){
		$name = 'uploadedfile';
		config('UPLOAD_SIZE',30*1024*1024);
		file_put_contents('runlog/fff.html',json_encode($_FILES));
		$result = uploadByName($name);
		if(!$result){
			return $this->errorReturn('文件格式或大小错误！.');
		}
		$result = show_resize_2($result);
		if(!$result){
			return $this->errorReturn('文件压缩失败');
		}

		//写入临时文件表
		$data = array('create_time'=>time(),'file_url'=>$result);
		db('Tempfile')->insert($data);
		$ext = getExt($result);
		$resize_file_url = show_resize($result);
		$return = array('file_url'=>$result,'ext'=>$ext,'file_size'=>filesize($result),'resize_file_url'=>$resize_file_url);
		return $this->successReturn('',$return);
	}
	//多文件上传
	public function upfilelists(){
		file_put_contents('runlog/fff.html',json_encode($_FILES));
		$path = config('UPLOAD_PATH');
		$files = request()->file('uploadedfile');
		
		$return = array();
		foreach($files as $file){
			// 移动到框架应用根目录/public/uploads/ 目录下
			$info = $file->validate(['size'=>config('UPLOAD_SIZE'),'ext'=>config('UPLOAD_EXT')])->move($path);
			if($info){
				$file_url = $path.$info->getSaveName();
				//写入临时文件表
				$data = array('create_time'=>time(),'file_url'=>$file_url);
				file_put_contents('runlog/fff1.html',json_encode($data));
				db('Tempfile')->insert($data);
				$return[] = $file_url;
			}  
		}
		
		return $this->successReturn('',$return);
	}
	public function indexinfo(){
		$ip = get_ip();
		
		$return = array();

		$cacheKey = md5('rl'.date('Ymd'));	
		$cacheVal = cache($cacheKey);
		if($cacheVal){
			$return['dates'] = $cacheVal.'.';
		}else{
			include_once(APP_PATH.'common/dates/lunar.php');
			$lunar=new \Lunar();
			$y = date('Y');
			$m = date('m');
			$d = date('d');

			$jieqi = $lunar->getJieQi($y,$m,$d);
			$yinli = $lunar->convertSolarToLunar($y,$m,$d);

			$arr = ['日','一','二','三','四','五','六'];
			$dates = "今天是 {$y}年{$m}月{$d}日 星期".$arr[date('N')]." 农历{$yinli[1]}{$yinli[2]} ".($jieqi['name2'] ? $jieqi['name2'] : $jieqi['name1']);
			cache($cacheKey,$dates,3600);
			$return['dates'] = $dates;	
		}

		$cityInfo = getipcity();
		$codes = $cityInfo['codes'];
		$city = $cityInfo['city'];
		
		$array = array();
		$array['wd'] = 0;
		$array['address'] = '';
		$array['info'] = '';

		$cacheKey = md5('tq_'.$city.date('Ymd'));
		$cacheVal = cache($cacheKey);
		if($cacheVal){
			
			$return['tq'] = $cacheVal;
		}else{
			if($city){
				$url = 'https://free-api.heweather.com/s6/weather/now?location='.$city.'&key=cfdc0526f5a44529b019c369c66b61f7';
				$tqInfo = https_request($url);//tqinfo($codes);
				$tqInfo = json_decode($tqInfo,true);
				
				
				if($tqInfo['HeWeather6'][0]['status']=='ok'){
					$array['wd'] = $tqInfo['HeWeather6'][0]['now']['tmp'];
					$array['address'] = $tqInfo['HeWeather6'][0]['basic']['admin_area'].'.'.$tqInfo['HeWeather6'][0]['basic']['location'];
					$array['info'] = $tqInfo['HeWeather6'][0]['now']['cond_txt'].' '.$tqInfo['HeWeather6'][0]['now']['wind_dir'];
					$array['times'] = date('Y-m-d H:i:s'); 
				}
				
			}
			cache($cacheKey,$array,7200);
			$return['tq'] = $array;
		}	

		return $this->successReturn('',$return);
	}









	//水泵
	public function sbhqsj(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$id = $this->Data['id'];
		$v_1 = '0b0200000000';//获取信息
		//$v_1 = '0b0500000000';//获取信息
		$v_1 = '0b0300000000';//获取信息
		//$v_1 = '090500020000';//关机
		//$v_1 = '090500010000';//开机

		
		
		if(!$v_1){
			return $this->errorReturn('参数错误');
		}
		

		$value_arr = array($v_1);
		
		$info = db('acccard')->where( array('id'=>$id,'account_id'=>$userId) )->cache(true)->find();
		if(!$info){
			return $this->errorReturn('未找到设备');
		}
		$card_id = $info['card_id'];
		
		//设备是否在线
		if(!isonline($card_id)){
			return $this->errorReturn('设备离线');
		}
		

		$data_type = 62;
		$card_type = $info['card_type'];
		$baseArr = config('baseArr');
		$title = $baseArr[$card_type][$data_type]['title'];
		$data = array();
		$data['account_id'] = $userId;
		$data['acccard_id'] = $id;
		$data['card_type'] = $info['card_type'];
		$data['card_id'] = $card_id;
		$data['data_type'] = $data_type;
		$data['title'] = $title;
		$data['value_json'] = json_encode($value_arr);
		$data['create_time'] = time();

		//db('datasend')->where( array('card_id'=>$card_id,'data_type'=>$data_type,'status'=>1) )->setField('status',4);
		$result = db('datasend')->insertGetId($data);
		file_put_contents('111.html',db('datasend')->getLastSql());

		if(!$result){
			return $this->errorReturn('操作失败');
		}
		//db('cardid')->where( array('card_id'=>$card_id) )->update(['tds_status'=>1,'tds_time'=>time()]);

		return $this->successReturn('操作成功');
	}
	//水泵工作模式详情
	public function sbyxmsinfo(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$id = $this->Data['id'];
		$info = db('acccard')->where( array('id'=>$id,'account_id'=>$userId) )->cache(true)->find();
		if(!$info){
			return $this->errorReturn('未找到设备');
		}
		$cardInfo = db('cardid')->where( array('card_id'=>$info['card_id']) )->find();

		if(!$cardInfo['value_json_sbyxms']){
			$arr = array(2);
		}else{
			$arr = json_decode($cardInfo['value_json_sbyxms'],true);
		}

		$return = array('sz_status'=>$cardInfo['sbyxms_status'],'sz_time'=>$cardInfo['sbyxms_time']);
		$return['v_1'] = $arr[0];
		return $this->successReturn('',$return);
	}
	//水泵工作模式设置
	public function sbyxms(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$id = $this->Data['id'];
		$v_1 = (int)$this->Data['v_1'];

		if($v_1!==1 && $v_1!==2 && $v_1!==3){
			return $this->errorReturn('参数错误');
		}
		
		

		
		$info = db('acccard')->where( array('id'=>$id,'account_id'=>$userId) )->cache(true)->find();
		if(!$info){
			return $this->errorReturn('未找到设备');
		}
		$card_id = $info['card_id'];
		
		//设备是否在线
		if(!isonline($card_id)){
			return $this->errorReturn('设备离线');
		}

		$cardInfo = db('cardid')->where( array('card_id'=>$card_id) )->find();

		if($v_1==1){	
			//投食
			$temp_field_name = 'sbts';
			$temp_arr = json_decode($cardInfo['value_json_'.$temp_field_name],true);
			if(is_array($temp_arr) && count($temp_arr)){
				$t_v_1 = $temp_arr[0];
				$t_v_2 = $temp_arr[1];
			}else{
				$t_v_1 = 10;
				$t_v_2 = 135;
			}
			$temp_16_1 = dechex($t_v_1);
			$temp_16_2 = dechex($t_v_2);
			$temp_16_1 = str_pad($temp_16_1,2,'0',STR_PAD_LEFT );
			$temp_16_2 = str_pad($temp_16_2,2,'0',STR_PAD_LEFT );
			$send_v_1 = '0901'.$temp_16_1.$temp_16_2.'0000';//
			$value_arr = array($t_v_1,$t_v_2);
			

		}elseif($v_1==2){
			//运行
			$temp_field_name = 'sbyx';
			$temp_arr = json_decode($cardInfo['value_json_'.$temp_field_name],true);
			if(is_array($temp_arr) && count($temp_arr)){
				$t_v_1 = $temp_arr[0];
			}else{
				$t_v_1 = 100;
			}
			$temp_16_1 = dechex($t_v_1);
			$temp_16_1 = str_pad($temp_16_1,2,'0',STR_PAD_LEFT );
			$send_v_1 = '090200'.$temp_16_1.'0000';
			$value_arr = array($t_v_1);
		}elseif($v_1==3){
			//造浪
			$temp_field_name = 'sbzl';
			$temp_arr = json_decode($cardInfo['value_json_'.$temp_field_name],true);
			if(is_array($temp_arr) && count($temp_arr)){
				$t_v_1 = $temp_arr[0];
			}else{
				$t_v_1 = 100;
			}
			$temp_16_1 = dechex($t_v_1);
			$temp_16_1 = str_pad($temp_16_1,2,'0',STR_PAD_LEFT );
			$send_v_1 = '090300'.$temp_16_1.'0000';//
			$value_arr = array($t_v_1);
		}else{
			return $this->errorReturn('参数错误');
		}

		
		$send_arr = array($send_v_1);
		

		$data_type = 62;
		$card_type = $info['card_type'];
		$baseArr = config('baseArr');
		$title = $baseArr[$card_type][$data_type]['title'];
		$data = array();
		$data['account_id'] = $userId;
		$data['acccard_id'] = $id;
		$data['card_type'] = $info['card_type'];
		$data['card_id'] = $card_id;
		$data['data_type'] = $data_type;
		$data['title'] = $title;
		$data['value_json'] = json_encode($send_arr);
		$data['create_time'] = time();

		db('datasend')->where( array('card_id'=>$card_id,'data_type'=>$data_type,'status'=>1) )->setField('status',4);
		$result = db('datasend')->insertGetId($data);
		
		if(!$result){
			return $this->errorReturn('操作失败');
		}

		db('cardid')->where( array('card_id'=>$card_id) )->update(['value_json_'.$temp_field_name=>json_encode($value_arr),$temp_field_name.'_status'=>1,$temp_field_name.'_time'=>time()]);
		db('cardid')->where( array('card_id'=>$card_id) )->update(['value_json_sbyxms'=>json_encode([$v_1]),'sbyxms_status'=>1,'sbyxms_time'=>time()]);

		return $this->successReturn('操作成功');

	}
	//水泵开关机详情
	public function sbkgjinfo(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$id = $this->Data['id'];
		$info = db('acccard')->where( array('id'=>$id,'account_id'=>$userId) )->cache(true)->find();
		if(!$info){
			return $this->errorReturn('未找到设备');
		}
		$cardInfo = db('cardid')->where( array('card_id'=>$info['card_id']) )->find();

		if(!$cardInfo['value_json_sbkgj']){
			$arr = array(1);
		}else{
			$arr = json_decode($cardInfo['value_json_sbkgj'],true);
		}

		$return = array('sz_status'=>$cardInfo['sbkgj_status'],'sz_time'=>$cardInfo['sbkgj_time']);
		$return['v_1'] = $arr[0];
		return $this->successReturn('',$return);
	}
	//水泵开关机
	public function sbkgj(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$id = $this->Data['id'];
		$v_1 = (int)$this->Data['v_1'];

		if($v_1!==1 && $v_1!==0){
			return $this->errorReturn('参数错误');
		}
		
		if($v_1==1){			
			$send_v_1 = '090500010000';//开机
		}else{
			$send_v_1 = '090500020000';//关机
		}

		$value_arr = array($v_1);
		$send_arr = array($send_v_1);

		
		$info = db('acccard')->where( array('id'=>$id,'account_id'=>$userId) )->cache(true)->find();
		if(!$info){
			return $this->errorReturn('未找到设备');
		}
		$card_id = $info['card_id'];
		
		//设备是否在线
		if(!isonline($card_id)){
			return $this->errorReturn('设备离线');
		}
		

		$data_type = 62;
		$card_type = $info['card_type'];
		$baseArr = config('baseArr');
		$title = $baseArr[$card_type][$data_type]['title'];
		$data = array();
		$data['account_id'] = $userId;
		$data['acccard_id'] = $id;
		$data['card_type'] = $info['card_type'];
		$data['card_id'] = $card_id;
		$data['data_type'] = $data_type;
		$data['title'] = $title;
		$data['value_json'] = json_encode($send_arr);
		$data['create_time'] = time();

		db('datasend')->where( array('card_id'=>$card_id,'data_type'=>$data_type,'status'=>1) )->setField('status',4);
		$result = db('datasend')->insertGetId($data);
		
		if(!$result){
			return $this->errorReturn('操作失败');
		}

		db('cardid')->where( array('card_id'=>$card_id) )->update(['value_json_sbkgj'=>json_encode($value_arr),'sbkgj_status'=>1,'sbkgj_time'=>time()]);

		return $this->successReturn('操作成功');

	}

	//水泵运行模式详情
	public function sbyxinfo(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$id = $this->Data['id'];
		$info = db('acccard')->where( array('id'=>$id,'account_id'=>$userId) )->cache(true)->find();
		if(!$info){
			return $this->errorReturn('未找到设备');
		}
		$cardInfo = db('cardid')->where( array('card_id'=>$info['card_id']) )->find();

		if(!$cardInfo['value_json_sbyx']){
			$arr = array(100);
		}else{
			$arr = json_decode($cardInfo['value_json_sbyx'],true);
		}


		$return = array('sz_status'=>$cardInfo['sbyx_status'],'sz_time'=>$cardInfo['sbyx_time']);
		$return['v_1'] = $arr[0];
		return $this->successReturn('',$return);
	}
	//水泵运行模式
	public function sbyx(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$id = $this->Data['id'];
		$v_1 = (int)$this->Data['v_1'];
		
		if($v_1<1 || $v_1>100){
			return $this->errorReturn('档位1-100');
		}
		
		$temp_16_1 = dechex($v_1);
		$temp_16_1 = str_pad($temp_16_1,2,'0',STR_PAD_LEFT );
		$send_v_1 = '090200'.$temp_16_1.'0000';//开机
		

		$value_arr = array($v_1);
		$send_arr = array($send_v_1);

		
		$info = db('acccard')->where( array('id'=>$id,'account_id'=>$userId) )->cache(true)->find();
		if(!$info){
			return $this->errorReturn('未找到设备');
		}
		$card_id = $info['card_id'];
		
		//设备是否在线
		if(!isonline($card_id)){
			return $this->errorReturn('设备离线');
		}
		

		$data_type = 62;
		$card_type = $info['card_type'];
		$baseArr = config('baseArr');
		$title = $baseArr[$card_type][$data_type]['title'];
		$data = array();
		$data['account_id'] = $userId;
		$data['acccard_id'] = $id;
		$data['card_type'] = $info['card_type'];
		$data['card_id'] = $card_id;
		$data['data_type'] = $data_type;
		$data['title'] = $title;
		$data['value_json'] = json_encode($send_arr);
		$data['create_time'] = time();

		db('datasend')->where( array('card_id'=>$card_id,'data_type'=>$data_type,'status'=>1) )->setField('status',4);
		$result = db('datasend')->insertGetId($data);
		
		if(!$result){
			return $this->errorReturn('操作失败');
		}

		db('cardid')->where( array('card_id'=>$card_id) )->update(['value_json_sbyx'=>json_encode($value_arr),'sbyx_status'=>1,'sbyx_time'=>time()]);

		return $this->successReturn('操作成功');

	}
	//水泵造浪模式详情
	public function sbzlinfo(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$id = $this->Data['id'];
		$info = db('acccard')->where( array('id'=>$id,'account_id'=>$userId) )->cache(true)->find();
		if(!$info){
			return $this->errorReturn('未找到设备');
		}
		$cardInfo = db('cardid')->where( array('card_id'=>$info['card_id']) )->find();

		if(!$cardInfo['value_json_sbzl']){
			$arr = array(1);
		}else{
			$arr = json_decode($cardInfo['value_json_sbzl'],true);
		}

		$return = array('sz_status'=>$cardInfo['sbzl_status'],'sz_time'=>$cardInfo['sbzl_time']);
		$return['v_1'] = $arr[0];
		return $this->successReturn('',$return);
	}
	//水泵造浪模式
	public function sbzl(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$id = $this->Data['id'];
		$v_1 = (int)$this->Data['v_1'];
		
		if($v_1<1 || $v_1>100){
			return $this->errorReturn('档位1-100');
		}
		$temp_16_1 = dechex($v_1);
		$temp_16_1 = str_pad($temp_16_1,2,'0',STR_PAD_LEFT );
		$send_v_1 = '090300'.$temp_16_1.'0000';//开机
		

		$value_arr = array($v_1);
		$send_arr = array($send_v_1);

		
		$info = db('acccard')->where( array('id'=>$id,'account_id'=>$userId) )->cache(true)->find();
		if(!$info){
			return $this->errorReturn('未找到设备');
		}
		$card_id = $info['card_id'];
		
		//设备是否在线
		if(!isonline($card_id)){
			return $this->errorReturn('设备离线');
		}
		

		$data_type = 62;
		$card_type = $info['card_type'];
		$baseArr = config('baseArr');
		$title = $baseArr[$card_type][$data_type]['title'];
		$data = array();
		$data['account_id'] = $userId;
		$data['acccard_id'] = $id;
		$data['card_type'] = $info['card_type'];
		$data['card_id'] = $card_id;
		$data['data_type'] = $data_type;
		$data['title'] = $title;
		$data['value_json'] = json_encode($send_arr);
		$data['create_time'] = time();

		db('datasend')->where( array('card_id'=>$card_id,'data_type'=>$data_type,'status'=>1) )->setField('status',4);
		$result = db('datasend')->insertGetId($data);
		
		if(!$result){
			return $this->errorReturn('操作失败');
		}

		db('cardid')->where( array('card_id'=>$card_id) )->update(['value_json_sbzl'=>json_encode($value_arr),'sbzl_status'=>1,'sbzl_time'=>time()]);

		return $this->successReturn('操作成功');

	}
	//水泵投食模式详情
	public function sbtsinfo(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$id = $this->Data['id'];
		$info = db('acccard')->where( array('id'=>$id,'account_id'=>$userId) )->cache(true)->find();
		if(!$info){
			return $this->errorReturn('未找到设备');
		}
		$cardInfo = db('cardid')->where( array('card_id'=>$info['card_id']) )->find();

		if(!$cardInfo['value_json_sbts']){
			$arr = array(10,135);
		}else{
			$arr = json_decode($cardInfo['value_json_sbts'],true);
		}

		$return = array('sz_status'=>$cardInfo['sbts_status'],'sz_time'=>$cardInfo['sbts_time']);
		$return['v_1'] = $arr[0];
		$return['v_2'] = $arr[1];
		return $this->successReturn('',$return);
	}
	//水泵造浪模式
	public function sbts(){
		$userInfo = gU();
		$userId = $userInfo['id'];

		$id = $this->Data['id'];
		$v_1 = (int)$this->Data['v_1'];
		$v_2 = (int)$this->Data['v_2'];
		
		if( ($v_1<10 || $v_1>135) || ($v_2<10 || $v_2>135) ){
			return $this->errorReturn('时间设置10-135秒');
		}
		
		//$send_v_1 = '090100'.dechex($v_1).'0000';//
		//$send_v_2 = '090100'.dechex($v_2).'0000';//
		$temp_16_1 = dechex($v_1);
		$temp_16_2 = dechex($v_2);
		$temp_16_1 = str_pad($temp_16_1,2,'0',STR_PAD_LEFT );
		$temp_16_2 = str_pad($temp_16_2,2,'0',STR_PAD_LEFT );

		$send_v_1 = '0901'.$temp_16_1.$temp_16_2.'0000';//

		$value_arr = array($v_1,$v_2);
		$send_arr = array($send_v_1);

		
		$info = db('acccard')->where( array('id'=>$id,'account_id'=>$userId) )->cache(true)->find();
		if(!$info){
			return $this->errorReturn('未找到设备');
		}
		$card_id = $info['card_id'];
		
		//设备是否在线
		if(!isonline($card_id)){
			return $this->errorReturn('设备离线');
		}
		

		$data_type = 62;
		$card_type = $info['card_type'];
		$baseArr = config('baseArr');
		$title = $baseArr[$card_type][$data_type]['title'];
		$data = array();
		$data['account_id'] = $userId;
		$data['acccard_id'] = $id;
		$data['card_type'] = $info['card_type'];
		$data['card_id'] = $card_id;
		$data['data_type'] = $data_type;
		$data['title'] = $title;
		$data['value_json'] = json_encode($send_arr);
		$data['create_time'] = time();

		db('datasend')->where( array('card_id'=>$card_id,'data_type'=>$data_type,'status'=>1) )->setField('status',4);
		$result = db('datasend')->insertGetId($data);
		
		if(!$result){
			return $this->errorReturn('操作失败');
		}

		db('cardid')->where( array('card_id'=>$card_id) )->update(['value_json_sbts'=>json_encode($value_arr),'sbts_status'=>1,'sbts_time'=>time()]);

		return $this->successReturn('操作成功');

	}
}
