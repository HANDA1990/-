<?php
namespace app\api\controller;

class Weixin extends Common {
	
	public function sm(){
		var_dump($_SESSION);
		print_r(session(config('WX_KEY')));
	}
	public function cs(){
		session(config('ACCOUNT_KEY'),null);
		session(config('WX_KEY'),null);
	}
	
	
	//code获取微信信息
	public function getwxuserinfo(){
		$code = gwhere('code');
		$from_url = session('tourl');
		$from_url = $from_url ? $from_url : '/';
		if($code){		
			$Wx = new \think\Weixin('isme',config('WX_AID'),config('WX_AST') );			
			$wxUserInfo = $Wx->getUserInfoByCode($code);
			
			if($wxUserInfo['openid']){
				if(!$wxUserInfo['subscribe']){
					//用户未关注				
					//session(config('WX_KEY'),null);		
					//echo '<script>window.location.href="/gzgzh.html";</script>';exit;
				}
				session(config('WX_KEY'),$wxUserInfo);
				$openid = $wxUserInfo['openid'];
				
			}else{
				file_put_contents('runlog/ccc.html',json_encode($wxUserInfo));
			}
		}
		
		echo '<script>window.location.href="'.$from_url.'";</script>';
		
	}
	
}

