<?php
namespace app\index\model;
use think\Model;

class Logs extends \think\Model
{
}